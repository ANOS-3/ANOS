import type { HabitatQuery, Language } from '../types/fireSafety';

export interface MissionPreset {
  id: string;
  labelEn: string;
  labelFr: string;
  subtitleEn: string;
  subtitleFr: string;
  questionEn: string;
  questionFr: string;
  query: Omit<HabitatQuery, 'questionText'>;
}

export const MISSION_PRESETS: MissionPreset[] = [
  {
    id: 'lunar-unknown-x',
    labelEn: 'Lunar Habitat: Fabric X',
    labelFr: 'Habitat Lunaire : Tissu X',
    subtitleEn: '34% O₂ · 0.6 atm · 15 cm/s Concurrent · 1/6g',
    subtitleFr: '34% O₂ · 0.6 atm · 15 cm/s Concurrent · 1/6g',
    questionEn:
      'My lunar habitat uses Fabric X, 34% O₂, 0.6 atm pressure, 15 cm/s concurrent airflow. What is the fire risk?',
    questionFr:
      'Mon habitat lunaire utilise du tissu X, O₂ 34%, pression 0.6 atm, flux d’air concurrent 15 cm/s. Quel est le risque incendie ?',
    query: {
      materialKey: 'UNKNOWN_CUSTOM',
      customMaterialName: 'Fabric X',
      o2Percent: 34,
      pressureAtm: 0.6,
      velocityCmS: 15,
      flowDirection: 'Concurrent',
      gravity: 'lunar',
      thicknessMm: null,
    },
  },
  {
    id: 'artemis-sibal',
    labelEn: 'Exploration SEA: SIBAL (34% O₂)',
    labelFr: 'Atmosphère SEA : SIBAL (34% O₂)',
    subtitleEn: '34% O₂ · 0.6 atm · 15 cm/s (MG-034 Audit)',
    subtitleFr: '34% O₂ · 0.6 atm · 15 cm/s (Audit MG-034)',
    questionEn:
      'Evaluate fire risk for SIBAL fabric in an Artemis SEA exploration habitat at 34% O₂, 0.6 atm, and 15 cm/s concurrent airflow.',
    questionFr:
      'Évaluez le risque incendie pour le tissu SIBAL dans une atmosphère SEA d’exploration à 34% O₂, 0.6 atm et 15 cm/s en flux concurrent.',
    query: {
      materialKey: 'Tissu SIBAL (Coton/Verre)',
      customMaterialName: '',
      o2Percent: 34,
      pressureAtm: 0.6,
      velocityCmS: 15,
      flowDirection: 'Concurrent',
      gravity: 'lunar',
      thicknessMm: 0.32,
    },
  },
  {
    id: 'saffire-iss',
    labelEn: 'ISS Standard: SIBAL (Saffire-1)',
    labelFr: 'Standard ISS : SIBAL (Saffire-1)',
    subtitleEn: '21.7% O₂ · 1.0 atm · 20 cm/s Concurrent',
    subtitleFr: '21.7% O₂ · 1.0 atm · 20 cm/s Concurrent',
    questionEn:
      'Compare SIBAL fabric at 21.7% O₂, 1.0 atm, and 20 cm/s concurrent airflow in 0g against the legacy calculator.',
    questionFr:
      'Comparez le tissu SIBAL à 21.7% O₂, 1.0 atm et 20 cm/s en microgravité 0g face au calculateur hérité.',
    query: {
      materialKey: 'Tissu SIBAL (Coton/Verre)',
      customMaterialName: '',
      o2Percent: 21.7,
      pressureAtm: 1.0,
      velocityCmS: 20,
      flowDirection: 'Concurrent',
      gravity: '0g',
      thicknessMm: 0.32,
    },
  },
  {
    id: 'low-flow-trap',
    labelEn: 'Low-Flow Quench Trap',
    labelFr: 'Piège Faible Ventilation',
    subtitleEn: 'SIBAL · 21% O₂ · 1.5 cm/s Concurrent',
    subtitleFr: 'SIBAL · 21% O₂ · 1.5 cm/s Concurrent',
    questionEn:
      'Is SIBAL fabric safe at 21% O₂, 1 atm when ventilation drops to 1.5 cm/s?',
    questionFr:
      'Le tissu SIBAL est-il sûr à 21% O₂, 1 atm lorsque la ventilation chute à 1.5 cm/s ?',
    query: {
      materialKey: 'Tissu SIBAL (Coton/Verre)',
      customMaterialName: '',
      o2Percent: 21,
      pressureAtm: 1.0,
      velocityCmS: 1.5,
      flowDirection: 'Concurrent',
      gravity: '0g',
      thicknessMm: 0.32,
    },
  },
  {
    id: 'flex-cool-flame',
    labelEn: 'FLEX Liquid Fuel: n-Decane',
    labelFr: 'Carburant Liquide FLEX : n-Décane',
    subtitleEn: '21% O₂ · 0.5 atm · Cool Flame Regime',
    subtitleFr: '21% O₂ · 0.5 atm · Régime Flamme Froide',
    questionEn:
      'What is the fire risk of an n-Decane liquid droplet leak at 21% O₂ and 0.5 atm in microgravity?',
    questionFr:
      'Quel est le risque incendie d’une fuite de goutte de n-Décane à 21% O₂ et 0.5 atm en microgravité ?',
    query: {
      materialKey: 'n-Décane (Goutte)',
      customMaterialName: '',
      o2Percent: 21,
      pressureAtm: 0.5,
      velocityCmS: 0,
      flowDirection: 'Stagnant',
      gravity: '0g',
      thicknessMm: null,
    },
  },
];

export function buildPresetQuery(preset: MissionPreset, language: Language): HabitatQuery {
  return {
    ...preset.query,
    customMaterialName:
      preset.id === 'lunar-unknown-x'
        ? language === 'fr'
          ? 'Tissu X'
          : 'Fabric X'
        : preset.query.customMaterialName,
    questionText: language === 'fr' ? preset.questionFr : preset.questionEn,
  };
}
