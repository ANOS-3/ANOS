export type RowType =
  | 'Essai solide'
  | 'Essai goutte'
  | 'Référence LOI'
  | 'Scénario habitat'
  | 'Calculateur initial';

export type FlowDirection = 'Concurrent' | 'Opposé' | 'Stagnant';

export type GravityEnvironment = '0g' | 'lunar' | 'mars';

export type Language = 'en' | 'fr';

export interface MicrogravityRecord {
  id: string;
  rowType: RowType;
  mission: string;
  sourceId: string;
  initialSheet: string;
  initialRow: string;
  dataNature: string;
  materialOriginal: string;
  materialFamily: string;
  loiKey: string;
  geometry: string;
  originalDimensions: string;
  thicknessMm: number | null;
  flowDirection: string;
  o2Percent: number | null;
  pressureAtm: number | null;
  velocityCmS: number | null;
  atmosphereDiluent: string;
  vfMmS: number | null;
  pyrolysisLengthCm: number | null;
  d0Mm: number | null;
  extHotMm: number | null;
  coolFlame: string;
  extColdMm: number | null;
  kHotMm2S: number | null;
  kColdMm2S: number | null;
  loiO2Threshold: number | null;
  uMinCmS: number | null;
  o2DeltaPts: number | null;
  pO2Atm: number | null;
  initialObservation: string;
  referenceConditions: string;
  legacyModelResult: string;
  thresholdComparison: string;
  validityDomain: string;
  indicatorNature: string;
  verificationStatus: string;
  scientificAlert: string;
  nasaPsiUrl: string;
  publicationUrl: string;
  provenanceLimits: string;
  originalFormulas: string;
}

export interface HabitatQuery {
  materialKey: string; // Matches loiKey or 'UNKNOWN_CUSTOM'
  customMaterialName: string;
  o2Percent: number;
  pressureAtm: number;
  velocityCmS: number;
  flowDirection: FlowDirection;
  gravity: GravityEnvironment;
  thicknessMm: number | null;
  questionText: string;
}

export type HonestVerdictLevel =
  | 'CRITICAL_PROPAGATION'
  | 'COOL_FLAME_INSTABILITY'
  | 'QUENCH_NOT_GUARANTEED'
  | 'OUT_OF_DOMAIN_UNKNOWN'
  | 'NO_PROPAGATION_OBSERVED';

export interface RankedEvidence {
  record: MicrogravityRecord;
  similarityScore: number; // 0 to 100
  matchReasons: string[];
  mismatchFlags: string[];
}

export interface LegacyModelComparison {
  legacyStatus: string;
  legacyRiskLabel: string;
  legacyVfMmS: number | null;
  legacyLoiUsed: number | null;
  legacyUMinUsed: number | null;
  divergenceWarnings: string[];
}

export interface HonestAssessment {
  verdictLevel: HonestVerdictLevel;
  confidenceLabel: 'Low (Extrapolated / Unknown)' | 'Moderate (Partial Analog)' | 'High (Near-Analog NASA Trial)';
  pO2Atm: number;
  isKnownMaterial: boolean;
  isDropletMaterial: boolean;
  matchedLoiRecord: MicrogravityRecord | null;
  loiO2Threshold: number | null;
  uMinThreshold: number | null;
  deltaO2Pts: number | null;
  estimatedVfRange: { min: number; max: number; basisIds: string[] } | null;
  domainViolations: string[];
  epistemicCaveats: string[];
  rankedEvidence: RankedEvidence[];
  closestExperimentalTrial: RankedEvidence | null;
  legacyComparison: LegacyModelComparison;
}

export interface SISynthesis {
  directAnswer: string;
  honestRiskSummary: string;
  evidenceBreakdown: string[];
  whatWeDoNotKnow: string[];
  safetyRecommendations: string[];
  citedRecordIds: string[];
  mode: 'gemini' | 'deterministic';
  modelName: string;
  generatedAt: string;
  notice?: string;
}
