import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { AstronautAnswerCard } from './components/AstronautAnswerCard';
import { DropletAndSpreadChart } from './components/DropletAndSpreadChart';
import { EvidenceExplorer } from './components/EvidenceExplorer';
import { FlammabilityRegimeMap } from './components/FlammabilityRegimeMap';
import { LegacyModelAudit } from './components/LegacyModelAudit';
import { RadialTelemetryGauges } from './components/RadialTelemetryGauges';
import { RankedMatchesSidebar } from './components/RankedMatchesSidebar';
import { RecordDetailDrawer } from './components/RecordDetailDrawer';
import { SISynthesisPanel } from './components/SISynthesisPanel';
import { SlideFilterBar } from './components/SlideFilterBar';
import { TelemetryRibbon } from './components/TelemetryRibbon';
import { TopBar, type SlideView } from './components/TopBar';
import { buildPresetQuery, MISSION_PRESETS } from './data/presets';
import { COPY } from './i18n/translations';
import { parseMicrogravityCsv } from './lib/csvParser';
import {
  buildDeterministicSynthesis,
  buildQuestionSummary,
  computeDomainChecks,
  evaluateHabitatRisk,
  parseNaturalLanguageQuestion,
} from './lib/fireSafetyEngine';
import type {
  HabitatQuery,
  Language,
  MicrogravityRecord,
  SISynthesis,
} from './types/fireSafety';

const INITIAL_PRESET = MISSION_PRESETS[0];

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [activeView, setActiveView] = useState<SlideView>('cockpit');
  const [records, setRecords] = useState<MicrogravityRecord[]>([]);
  const [datasetError, setDatasetError] = useState<string | null>(null);
  const [query, setQuery] = useState<HabitatQuery>(() =>
    buildPresetQuery(INITIAL_PRESET, 'en')
  );
  const [activePresetId, setActivePresetId] = useState<string | null>(INITIAL_PRESET.id);
  const [synthesis, setSynthesis] = useState<SISynthesis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [selectedRecord, setSelectedRecord] = useState<MicrogravityRecord | null>(null);
  const [showFullBriefModal, setShowFullBriefModal] = useState(false);

  const questionInputRef = useRef<HTMLInputElement | null>(null);
  const questionEditedRef = useRef(false);
  const copy = COPY[language];

  const recordsById = useMemo(() => {
    const map = new Map<string, MicrogravityRecord>();
    for (const r of records) map.set(r.id, r);
    return map;
  }, [records]);

  const assessment = useMemo(() => {
    return evaluateHabitatRisk(records, query, language);
  }, [records, query, language]);

  const domainSummary = useMemo(() => {
    return computeDomainChecks(assessment, query, language);
  }, [assessment, query, language]);

  const runSIAnalysis = useCallback(
    async (targetQuery: HabitatQuery, targetLang: Language, currentRecords: MicrogravityRecord[]) => {
      if (currentRecords.length > 0) {
        const instantAssessment = evaluateHabitatRisk(currentRecords, targetQuery, targetLang);
        setSynthesis(buildDeterministicSynthesis(instantAssessment, targetQuery, targetLang));
      }
      setIsAnalyzing(true);
      setAnalysisError(null);
      try {
        const res = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: targetQuery,
            questionText: targetQuery.questionText,
            language: targetLang,
          }),
        });
        if (!res.ok) {
          throw new Error(`Analysis endpoint returned ${res.status}`);
        }
        const data = (await res.json()) as {
          synthesis: SISynthesis;
        };
        setSynthesis(data.synthesis);
      } catch (err) {
        if (currentRecords.length > 0) {
          const localAssessment = evaluateHabitatRisk(currentRecords, targetQuery, targetLang);
          setSynthesis(
            buildDeterministicSynthesis(
              localAssessment,
              targetQuery,
              targetLang,
              err instanceof Error ? err.message : 'Local NASA-PSI fallback active.'
            )
          );
        } else {
          setAnalysisError(
            err instanceof Error ? err.message : 'Failed to run fire-safety analysis.'
          );
        }
      } finally {
        setIsAnalyzing(false);
      }
    },
    []
  );

  // Load dataset on mount
  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        let loaded: MicrogravityRecord[] = [];
        try {
          const apiRes = await fetch('/api/dataset');
          if (apiRes.ok) {
            const payload = (await apiRes.json()) as { records: MicrogravityRecord[] };
            loaded = payload.records;
          }
        } catch {
          // Fallback to static CSV asset if API unavailable
        }

        if (loaded.length === 0) {
          const csvRes = await fetch(
            '/assets/aistudio/Tableau_Unique_Securite_Incendie_Microgravite_e4795b6a.csv'
          );
          if (!csvRes.ok) {
            throw new Error(`Could not load NASA CSV dataset (${csvRes.status})`);
          }
          const csvText = await csvRes.text();
          loaded = parseMicrogravityCsv(csvText);
        }

        if (!cancelled) {
          setRecords(loaded);
          const initialQuery = buildPresetQuery(INITIAL_PRESET, 'en');
          setQuery(initialQuery);
          void runSIAnalysis(initialQuery, 'en', loaded);
        }
      } catch (err) {
        if (!cancelled) {
          setDatasetError(
            err instanceof Error ? err.message : 'Failed to load NASA dataset.'
          );
        }
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [runSIAnalysis]);

  // Escape closes modals
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        if (selectedRecord) setSelectedRecord(null);
        else if (showFullBriefModal) setShowFullBriefModal(false);
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedRecord, showFullBriefModal]);

  function handleUpdateQuery(patch: Partial<HabitatQuery>) {
    setActivePresetId(null);
    if ('questionText' in patch && Object.keys(patch).length === 1) {
      questionEditedRef.current = true;
      setQuery({ ...query, ...patch });
      return;
    }

    questionEditedRef.current = false;
    const normalizedPatch = { ...patch };
    if (normalizedPatch.flowDirection === 'Stagnant' && !('velocityCmS' in normalizedPatch)) {
      normalizedPatch.velocityCmS = 0;
    } else if (
      typeof normalizedPatch.velocityCmS === 'number' &&
      normalizedPatch.velocityCmS > 0 &&
      query.flowDirection === 'Stagnant' &&
      !('flowDirection' in normalizedPatch)
    ) {
      normalizedPatch.flowDirection = 'Concurrent';
    }

    const merged = { ...query, ...normalizedPatch };
    const next: HabitatQuery = {
      ...merged,
      questionText: buildQuestionSummary(merged, language),
    };
    setQuery(next);
    if (records.length > 0) {
      const instant = evaluateHabitatRisk(records, next, language);
      setSynthesis(buildDeterministicSynthesis(instant, next, language));
    }
  }

  function handleSelectPreset(presetId: string) {
    const preset = MISSION_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    questionEditedRef.current = false;
    setActivePresetId(preset.id);
    const nextQuery = buildPresetQuery(preset, language);
    setQuery(nextQuery);
    void runSIAnalysis(nextQuery, language, records);
  }

  function handleAskQuestion() {
    const trimmed = query.questionText.trim();
    const nextQuery =
      questionEditedRef.current && trimmed
        ? parseNaturalLanguageQuestion(trimmed, query)
        : query;
    questionEditedRef.current = false;
    setQuery(nextQuery);
    void runSIAnalysis(nextQuery, language, records);
  }

  function handleFocusQuestion() {
    setTimeout(() => {
      const el = questionInputRef.current;
      if (el) {
        el.focus();
      }
    }, 30);
  }

  function handleExportBrief() {
    const brief = {
      exportedAt: new Date().toISOString(),
      query,
      assessment: {
        verdictLevel: assessment.verdictLevel,
        confidenceLabel: assessment.confidenceLabel,
        pO2Atm: assessment.pO2Atm,
        loiO2Threshold: assessment.loiO2Threshold,
        uMinThreshold: assessment.uMinThreshold,
        deltaO2Pts: assessment.deltaO2Pts,
        domainChecks: domainSummary.checks,
        domainViolations: assessment.domainViolations,
        epistemicCaveats: assessment.epistemicCaveats,
        legacyComparison: assessment.legacyComparison,
        topEvidenceIds: assessment.rankedEvidence.slice(0, 5).map((e) => ({
          id: e.record.id,
          similarityScore: e.similarityScore,
          mission: e.record.mission,
        })),
      },
      synthesis,
    };
    const blob = new Blob([JSON.stringify(brief, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nasa-fire-safety-brief-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen lg:h-screen lg:overflow-hidden bg-slate-50 text-slate-900 flex flex-col">
      <TopBar
        language={language}
        activeView={activeView}
        onSelectView={setActiveView}
        onFocusQuestion={handleFocusQuestion}
      />

      <TelemetryRibbon
        copy={copy}
        language={language}
        onLanguageChange={(nextLang) => {
          setLanguage(nextLang);
          let nextQuery = query;
          if (activePresetId) {
            const preset = MISSION_PRESETS.find((p) => p.id === activePresetId);
            if (preset) {
              nextQuery = buildPresetQuery(preset, nextLang);
              setQuery(nextQuery);
            }
          } else if (!questionEditedRef.current) {
            nextQuery = {
              ...query,
              questionText: buildQuestionSummary(query, nextLang),
            };
            setQuery(nextQuery);
          }
          if (records.length > 0) {
            void runSIAnalysis(nextQuery, nextLang, records);
          }
        }}
        onExportBrief={handleExportBrief}
        recordCount={records.length}
      />

      <SlideFilterBar
        language={language}
        query={query}
        isAnalyzing={isAnalyzing}
        activePresetId={activePresetId}
        questionInputRef={questionInputRef}
        onUpdateQuery={handleUpdateQuery}
        onSelectPreset={handleSelectPreset}
        onAskQuestion={handleAskQuestion}
      />

      <main className="mx-auto w-full max-w-[1440px] flex-1 min-h-0 px-4 py-3 lg:px-6">
        {datasetError && (
          <div
            role="alert"
            className="mb-3 rounded-md border border-rose-200 bg-rose-50 px-4 py-2 text-xs text-rose-800"
          >
            {datasetError}
          </div>
        )}

        {activeView === 'cockpit' && (
          <div className="grid h-full grid-cols-1 gap-4 lg:grid-cols-12">
            {/* Left Slide Column: Radial Gauges + Honest Astronaut Answer */}
            <div className="flex flex-col gap-3 lg:col-span-4 min-h-0">
              <RadialTelemetryGauges
                query={query}
                assessment={assessment}
                domainChecks={domainSummary}
                language={language}
              />
              <AstronautAnswerCard
                copy={copy}
                language={language}
                assessment={assessment}
                domainChecks={domainSummary.checks}
                synthesis={synthesis}
                isAnalyzing={isAnalyzing}
                onOpenFullBrief={() => setShowFullBriefModal(true)}
                recordsById={recordsById}
                onSelectRecord={setSelectedRecord}
              />
            </div>

            {/* Center Slide Column: Interactive Regime Map + Spread/Droplet Circles */}
            <div className="flex flex-col gap-3 lg:col-span-5 min-h-0">
              <FlammabilityRegimeMap
                copy={copy}
                language={language}
                records={records}
                query={query}
                assessment={assessment}
                onSelectRecord={setSelectedRecord}
              />
              <DropletAndSpreadChart
                records={records}
                language={language}
                onSelectRecord={setSelectedRecord}
              />
            </div>

            {/* Right Slide Column: Ranked Analog NASA Trials */}
            <div className="lg:col-span-3 min-h-0">
              <RankedMatchesSidebar
                rankedEvidence={assessment.rankedEvidence}
                language={language}
                onSelectRecord={setSelectedRecord}
                onOpenDeepVision={() => setActiveView('archive')}
              />
            </div>
          </div>
        )}

        {activeView === 'archive' && (
          <div className="h-full overflow-y-auto pr-1">
            <EvidenceExplorer
              copy={copy}
              language={language}
              rankedEvidence={assessment.rankedEvidence}
              onSelectRecord={setSelectedRecord}
            />
          </div>
        )}

        {activeView === 'audit' && (
          <div className="h-full overflow-y-auto pr-1">
            <LegacyModelAudit
              copy={copy}
              language={language}
              records={records}
              onSelectRecord={setSelectedRecord}
            />
          </div>
        )}
      </main>

      {/* Full SI Synthesis Modal */}
      {showFullBriefModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={copy.siSynthesisHeading}
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          onClick={() => setShowFullBriefModal(false)}
        >
          <div
            className="relative max-h-[88vh] w-full max-w-3xl overflow-y-auto rounded-lg bg-white shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setShowFullBriefModal(false)}
              aria-label={copy.closeModal}
              className="absolute right-4 top-4 z-10 rounded-md border border-slate-200 bg-white p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>
            <SISynthesisPanel
              copy={copy}
              synthesis={synthesis}
              isLoading={isAnalyzing}
              error={analysisError}
              recordsById={recordsById}
              onSelectRecord={(rec) => {
                setShowFullBriefModal(false);
                setSelectedRecord(rec);
              }}
              onRetry={() => void runSIAnalysis(query, language, records)}
            />
          </div>
        </div>
      )}

      <RecordDetailDrawer
        copy={copy}
        language={language}
        record={selectedRecord}
        onClose={() => setSelectedRecord(null)}
      />
    </div>
  );
}
