import type { HonestVerdictLevel, Language } from '../types/fireSafety';

export interface CopyDictionary {
  brandTitle: string;
  navAnalyzer: string;
  navRegimeMap: string;
  navEvidence: string;
  navAudit: string;
  topCta: string;
  ribbonDataset: string;
  ribbonMissions: string;
  ribbonStandard: string;
  exportBrief: string;
  questionHeading: string;
  questionPlaceholder: string;
  analyzeBtn: string;
  analyzingBtn: string;
  presetsLabel: string;
  parametersHeading: string;
  materialLabel: string;
  unknownMaterialOption: string;
  customMaterialLabel: string;
  o2Label: string;
  pressureLabel: string;
  velocityLabel: string;
  flowDirectionLabel: string;
  gravityLabel: string;
  gravityOptions: Record<'0g' | 'lunar' | 'mars', string>;
  verdictLabels: Record<HonestVerdictLevel, { glyph: string; title: string; subtitle: string }>;
  kpiPO2: string;
  kpiDeltaLoi: string;
  kpiAnalogRate: string;
  kpiConfidence: string;
  legacyVsHonestHeading: string;
  legacyColLabel: string;
  honestColLabel: string;
  domainAuditHeading: string;
  siSynthesisHeading: string;
  siDirectAnswer: string;
  siEvidence: string;
  siUnknowns: string;
  siRecommendations: string;
  regimeMapHeading: string;
  regimeMapSubtitle: string;
  evidenceHeading: string;
  evidenceSubtitle: string;
  searchPlaceholder: string;
  auditSectionHeading: string;
  auditSectionSubtitle: string;
  inspectRecord: string;
  closeModal: string;
}

export const COPY: Record<Language, CopyDictionary> = {
  en: {
    brandTitle: 'Microgravity Fire Lab',
    navAnalyzer: 'Analyzer',
    navRegimeMap: 'Regime Map',
    navEvidence: 'Evidence',
    navAudit: 'Model Audit',
    topCta: 'Ask SI Engine',
    ribbonDataset: '39 NASA PSI & ISS Records',
    ribbonMissions: 'Saffire-1/2/3 · BASS-II · FLEX',
    ribbonStandard: 'NASA-STD-6001 Audit',
    exportBrief: 'Export JSON Brief',
    questionHeading: 'Habitat Fire Safety Question',
    questionPlaceholder:
      'e.g. Mon habitat lunaire utilise du tissu X, O₂ 34%, pression 0.6 atm, flux d’air concurrent 15 cm/s. Quel est le risque incendie ?',
    analyzeBtn: 'Analyze Risk',
    analyzingBtn: 'Synthesizing...',
    presetsLabel: 'Mission Scenarios',
    parametersHeading: 'Habitat Boundary Parameters',
    materialLabel: 'Material / Fuel',
    unknownMaterialOption: 'Unknown / Unlisted Material (e.g. Fabric X)',
    customMaterialLabel: 'Custom Material Identifier',
    o2Label: 'Oxygen Concentration (O₂)',
    pressureLabel: 'Total Pressure',
    velocityLabel: 'Airflow Velocity (U)',
    flowDirectionLabel: 'Flow Direction',
    gravityLabel: 'Gravity Regime',
    gravityOptions: {
      '0g': '0g Microgravity',
      lunar: '1/6g Lunar',
      mars: '0.38g Mars',
    },
    verdictLabels: {
      CRITICAL_PROPAGATION: {
        glyph: '✖',
        title: 'Critical Active Propagation Risk',
        subtitle: 'Parameters exceed indicative LOI and minimum flow thresholds.',
      },
      COOL_FLAME_INSTABILITY: {
        glyph: '▲',
        title: 'Cool-Flame / Two-Stage Instability',
        subtitle: 'Liquid droplet trials show invisible low-temperature burning after hot extinction.',
      },
      QUENCH_NOT_GUARANTEED: {
        glyph: '▲',
        title: 'Quench Possible — Safety Not Guaranteed',
        subtitle: 'O₂ exceeds LOI; any ventilation transient or convection can re-ignite active spread.',
      },
      OUT_OF_DOMAIN_UNKNOWN: {
        glyph: '▲',
        title: 'Out-of-Domain — Uncertified Material / Regime',
        subtitle: 'Requested material or habitat state lacks direct NASA microgravity validation.',
      },
      NO_PROPAGATION_OBSERVED: {
        glyph: '●',
        title: 'Below Indicative Threshold (Uncertified)',
        subtitle: 'No spread observed within narrow 0g reference bounds; not a universal certification.',
      },
    },
    kpiPO2: 'Partial Pressure pO₂',
    kpiDeltaLoi: 'Margin vs Indicative LOI',
    kpiAnalogRate: 'Closest Measured Rate',
    kpiConfidence: 'Epistemic Confidence',
    legacyVsHonestHeading: 'Legacy Spreadsheet Model vs. Honest NASA Audit',
    legacyColLabel: 'Legacy Calculateur_Risque (IF/VLOOKUP)',
    honestColLabel: 'Honest NASA-PSI Evidence Audit',
    domainAuditHeading: 'Domain-of-Validity Violations & Scientific Caveats',
    siSynthesisHeading: 'Super Intelligence (SI) Safety Synthesis',
    siDirectAnswer: 'Direct Engineering Answer',
    siEvidence: 'Ranked NASA Experimental Evidence',
    siUnknowns: 'What We Do Not Know & Data Gaps',
    siRecommendations: 'Habitat Qualification & Safety Actions',
    regimeMapHeading: 'Microgravity Flammability & Extinction Regime Map',
    regimeMapSubtitle:
      'Airflow U (cm/s) vs. O₂ (%) showing NASA flight measurements, indicative non-certified LOI/Umin bounds, and your habitat operating crosshair.',
    evidenceHeading: 'Ranked NASA Microgravity Evidence Archive',
    evidenceSubtitle:
      'All 39 consolidated records ranked by parametric similarity to your habitat configuration. Click any row for full scientific provenance and alerts.',
    searchPlaceholder: 'Filter by MG-ID, material, mission, or alert...',
    auditSectionHeading: 'Legacy Model Audit: Where Naive Thresholds Fail',
    auditSectionSubtitle:
      'Direct discrepancies documented inside NASA PSI & Calculateur_Risque rows (MG-001..MG-039).',
    inspectRecord: 'Inspect Provenance',
    closeModal: 'Close',
  },
  fr: {
    brandTitle: 'Microgravity Fire Lab',
    navAnalyzer: 'Analyseur',
    navRegimeMap: 'Carte Régimes',
    navEvidence: 'Preuves NASA',
    navAudit: 'Audit Modèle',
    topCta: 'Interroger SI',
    ribbonDataset: '39 Fiches NASA PSI & ISS',
    ribbonMissions: 'Saffire-1/2/3 · BASS-II · FLEX',
    ribbonStandard: 'Audit NASA-STD-6001',
    exportBrief: 'Exporter JSON',
    questionHeading: 'Question Sécurité Incendie Habitat',
    questionPlaceholder:
      'ex : Mon habitat lunaire utilise du tissu X, O₂ 34%, pression 0.6 atm, flux d’air concurrent 15 cm/s. Quel est le risque incendie ?',
    analyzeBtn: 'Analyser le Risque',
    analyzingBtn: 'Synthèse SI...',
    presetsLabel: 'Scénarios de Mission',
    parametersHeading: 'Paramètres Limites de l’Habitat',
    materialLabel: 'Matériau / Combustible',
    unknownMaterialOption: 'Matériau Inconnu / Non Listé (ex. Tissu X)',
    customMaterialLabel: 'Nom du Matériau Personnalisé',
    o2Label: 'Concentration Oxygène (O₂)',
    pressureLabel: 'Pression Totale',
    velocityLabel: 'Vitesse Flux d’Air (U)',
    flowDirectionLabel: 'Direction du Flux',
    gravityLabel: 'Régime de Gravité',
    gravityOptions: {
      '0g': '0g Microgravité',
      lunar: '1/6g Lunaire',
      mars: '0.38g Mars',
    },
    verdictLabels: {
      CRITICAL_PROPAGATION: {
        glyph: '✖',
        title: 'Risque Critique de Propagation Active',
        subtitle: 'O₂ et vitesse U dépassent les seuils indicatifs de propagation.',
      },
      COOL_FLAME_INSTABILITY: {
        glyph: '▲',
        title: 'Instabilité / Flamme Froide Possible',
        subtitle: 'Les essais gouttes FLEX montrent une combustion froide quasi invisible après extinction chaude.',
      },
      QUENCH_NOT_GUARANTEED: {
        glyph: '▲',
        title: 'Extinction Radiative Possible — Non Garantie',
        subtitle: 'O₂ dépasse le seuil LOI ; toute reprise de ventilation ou convection relance le feu.',
      },
      OUT_OF_DOMAIN_UNKNOWN: {
        glyph: '▲',
        title: 'Hors Domaine — Matériau / Régime Non Validé',
        subtitle: 'Le matériau ou les conditions d’habitat n’ont aucune validation expérimentale directe NASA.',
      },
      NO_PROPAGATION_OBSERVED: {
        glyph: '●',
        title: 'Sous le Seuil Indicatif (Non Certifié)',
        subtitle: 'Aucune propagation observée dans les bornes étroites 0g ; ne vaut pas certification universelle.',
      },
    },
    kpiPO2: 'Pression Partielle pO₂',
    kpiDeltaLoi: 'Écart vs Seuil LOI',
    kpiAnalogRate: 'Taux Mesuré le Plus Proche',
    kpiConfidence: 'Confiance Épistémique',
    legacyVsHonestHeading: 'Modèle Tableur Hérité vs. Audit NASA Honnête',
    legacyColLabel: 'Calculateur_Risque Hérité (IF/VLOOKUP)',
    honestColLabel: 'Audit Scientifique NASA-PSI',
    domainAuditHeading: 'Violations du Domaine de Validité & Alertes Scientifiques',
    siSynthesisHeading: 'Synthèse Super Intelligence (SI)',
    siDirectAnswer: 'Réponse Directe d’Ingénierie',
    siEvidence: 'Preuves Expérimentales NASA Classées',
    siUnknowns: 'Ce Que Nous Ignorons & Limites des Données',
    siRecommendations: 'Actions de Qualification & Sécurité Habitat',
    regimeMapHeading: 'Carte des Régimes d’Inflammabilité & d’Extinction',
    regimeMapSubtitle:
      'Vitesse d’air U (cm/s) vs O₂ (%) : essais vol NASA, seuils indicatifs non certifiés LOI/Umin et point de fonctionnement de votre habitat.',
    evidenceHeading: 'Archive Classée des Preuves NASA Microgravité',
    evidenceSubtitle:
      'Les 39 fiches consolidées classées par similarité paramétrique. Cliquez sur une ligne pour consulter la provenance et les alertes.',
    searchPlaceholder: 'Filtrer par ID MG, matériau, mission ou alerte...',
    auditSectionHeading: 'Audit du Modèle Hérité : Où les Seuils Simples Échouent',
    auditSectionSubtitle:
      'Divergences quantitatives documentées dans les fiches NASA PSI & Calculateur_Risque (MG-001..MG-039).',
    inspectRecord: 'Voir Provenance',
    closeModal: 'Fermer',
  },
};
