import type { MicrogravityRecord, RowType } from '../types/fireSafety';

function parseNullableFloat(raw: string | undefined): number | null {
  if (!raw) return null;
  const normalized = raw.trim().replace(',', '.');
  if (normalized === '') return null;
  const num = Number(normalized);
  return Number.isFinite(num) ? num : null;
}

/**
 * RFC-4180 CSV parser supporting UTF-8 BOM, quoted newlines, and escaped quotes ("").
 */
export function parseCsvMatrix(csvText: string): string[][] {
  const cleanText = csvText.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < cleanText.length; i += 1) {
    const ch = cleanText[i];

    if (inQuotes) {
      if (ch === '"') {
        const next = cleanText[i + 1];
        if (next === '"') {
          currentField += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        currentField += ch;
      }
      continue;
    }

    if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      currentRow.push(currentField);
      currentField = '';
    } else if (ch === '\r') {
      if (cleanText[i + 1] === '\n') {
        i += 1;
      }
      currentRow.push(currentField);
      if (currentRow.some((cell) => cell.trim() !== '')) {
        rows.push(currentRow);
      }
      currentRow = [];
      currentField = '';
    } else if (ch === '\n') {
      currentRow.push(currentField);
      if (currentRow.some((cell) => cell.trim() !== '')) {
        rows.push(currentRow);
      }
      currentRow = [];
      currentField = '';
    } else {
      currentField += ch;
    }
  }

  if (currentField.length > 0 || currentRow.length > 0) {
    currentRow.push(currentField);
    if (currentRow.some((cell) => cell.trim() !== '')) {
      rows.push(currentRow);
    }
  }

  return rows;
}

export function parseMicrogravityCsv(csvText: string): MicrogravityRecord[] {
  const matrix = parseCsvMatrix(csvText);
  if (matrix.length < 2) return [];

  const records: MicrogravityRecord[] = [];
  for (let r = 1; r < matrix.length; r += 1) {
    const cols = matrix[r];
    if (!cols[0] || !cols[0].trim()) continue;

    const o2 = parseNullableFloat(cols[14]);
    const pressure = parseNullableFloat(cols[15]);
    const parsedPO2 = parseNullableFloat(cols[29]);
    const computedPO2 =
      parsedPO2 !== null
        ? parsedPO2
        : o2 !== null && pressure !== null
          ? Number(((o2 / 100) * pressure).toFixed(4))
          : null;

    records.push({
      id: (cols[0] ?? '').trim(),
      rowType: ((cols[1] ?? '').trim() || 'Essai solide') as RowType,
      mission: (cols[2] ?? '').trim(),
      sourceId: (cols[3] ?? '').trim(),
      initialSheet: (cols[4] ?? '').trim(),
      initialRow: (cols[5] ?? '').trim(),
      dataNature: (cols[6] ?? '').trim(),
      materialOriginal: (cols[7] ?? '').trim(),
      materialFamily: (cols[8] ?? '').trim(),
      loiKey: (cols[9] ?? '').trim(),
      geometry: (cols[10] ?? '').trim(),
      originalDimensions: (cols[11] ?? '').trim(),
      thicknessMm: parseNullableFloat(cols[12]),
      flowDirection: (cols[13] ?? '').trim(),
      o2Percent: o2,
      pressureAtm: pressure,
      velocityCmS: parseNullableFloat(cols[16]),
      atmosphereDiluent: (cols[17] ?? '').trim(),
      vfMmS: parseNullableFloat(cols[18]),
      pyrolysisLengthCm: parseNullableFloat(cols[19]),
      d0Mm: parseNullableFloat(cols[20]),
      extHotMm: parseNullableFloat(cols[21]),
      coolFlame: (cols[22] ?? '').trim(),
      extColdMm: parseNullableFloat(cols[23]),
      kHotMm2S: parseNullableFloat(cols[24]),
      kColdMm2S: parseNullableFloat(cols[25]),
      loiO2Threshold: parseNullableFloat(cols[26]),
      uMinCmS: parseNullableFloat(cols[27]),
      o2DeltaPts: parseNullableFloat(cols[28]),
      pO2Atm: computedPO2,
      initialObservation: (cols[30] ?? '').trim(),
      referenceConditions: (cols[31] ?? '').trim(),
      legacyModelResult: (cols[32] ?? '').trim(),
      thresholdComparison: (cols[33] ?? '').trim(),
      validityDomain: (cols[34] ?? '').trim(),
      indicatorNature: (cols[35] ?? '').trim(),
      verificationStatus: (cols[36] ?? '').trim(),
      scientificAlert: (cols[37] ?? '').trim(),
      nasaPsiUrl: (cols[38] ?? '').trim(),
      publicationUrl: (cols[39] ?? '').trim(),
      provenanceLimits: (cols[40] ?? '').trim(),
      originalFormulas: (cols[41] ?? '').trim(),
    });
  }

  return records;
}
