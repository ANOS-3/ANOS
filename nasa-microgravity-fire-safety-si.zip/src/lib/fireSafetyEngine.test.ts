import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { parseMicrogravityCsv } from './csvParser';
import {
  UNKNOWN_MATERIAL_KEY,
  buildDeterministicSynthesis,
  buildQuestionSummary,
  computeDomainChecks,
  detectLanguageFromText,
  evaluateHabitatRisk,
  parseNaturalLanguageQuestion,
} from './fireSafetyEngine';

const csvPath = path.resolve(
  process.cwd(),
  'public/assets/aistudio/Tableau_Unique_Securite_Incendie_Microgravite_e4795b6a.csv'
);
const csvRaw = fs.readFileSync(csvPath, 'utf8');
const records = parseMicrogravityCsv(csvRaw);

test('parses all 39 NASA microgravity records including multiline legacy formulas', () => {
  assert.equal(records.length, 39);
  assert.equal(records[0].id, 'MG-001');
  assert.equal(records[0].mission, 'SAFFIRE-1');
  assert.equal(records[0].vfMmS, 1.75);
  assert.equal(records[38].id, 'MG-039');
  assert.ok(records[38].originalFormulas.includes('B17:'));
  assert.ok(records[38].scientificAlert.includes('1,75 mm/s'));
});

test('parses French lunar habitat question with unknown Tissu X accurately', () => {
  const question =
    'Mon habitat lunaire utilise du tissu X, O₂ 34%, pression 0.6 atm, flux d’air concurrent 15 cm/s. Quel est le risque incendie ?';
  const parsed = parseNaturalLanguageQuestion(question);

  assert.equal(parsed.materialKey, UNKNOWN_MATERIAL_KEY);
  assert.ok(parsed.customMaterialName.toLowerCase().includes('tissu x'));
  assert.equal(parsed.o2Percent, 34);
  assert.equal(parsed.pressureAtm, 0.6);
  assert.equal(parsed.velocityCmS, 15);
  assert.equal(parsed.flowDirection, 'Concurrent');
  assert.equal(parsed.gravity, 'lunar');
  assert.equal(detectLanguageFromText(question), 'fr');

  const assessment = evaluateHabitatRisk(records, parsed);
  assert.equal(assessment.verdictLevel, 'OUT_OF_DOMAIN_UNKNOWN');
  assert.equal(assessment.isKnownMaterial, false);
  assert.equal(assessment.pO2Atm, 0.204);
  assert.ok(assessment.domainViolations.length >= 3); // unknown material + lunar 1/6g + 0.6 atm
});

test('exposes legacy model false security on low-flow SIBAL (MG-035 trap)', () => {
  const assessment = evaluateHabitatRisk(
    records,
    {
      materialKey: 'Tissu SIBAL (Coton/Verre)',
      customMaterialName: '',
      o2Percent: 21,
      pressureAtm: 1.0,
      velocityCmS: 1.5,
      flowDirection: 'Concurrent',
      gravity: '0g',
      thicknessMm: 0.32,
      questionText: '',
    },
    'en'
  );

  assert.equal(assessment.verdictLevel, 'QUENCH_NOT_GUARANTEED');
  assert.ok(assessment.legacyComparison.legacyStatus.includes('Radiative Extinction'));
  assert.ok(
    assessment.legacyComparison.divergenceWarnings.some((w) => w.includes('MG-035'))
  );

  const assessmentFr = evaluateHabitatRisk(
    records,
    {
      materialKey: 'Tissu SIBAL (Coton/Verre)',
      customMaterialName: '',
      o2Percent: 21,
      pressureAtm: 1.0,
      velocityCmS: 1.5,
      flowDirection: 'Concurrent',
      gravity: '0g',
      thicknessMm: 0.32,
      questionText: '',
    },
    'fr'
  );
  assert.ok(assessmentFr.legacyComparison.legacyStatus.includes('Extinction Radiative'));
});

test('exposes legacy Vf=3.25 vs Saffire-1 Vf=1.75 discrepancy (MG-039 vs MG-001)', () => {
  const assessment = evaluateHabitatRisk(records, {
    materialKey: 'Tissu SIBAL (Coton/Verre)',
    customMaterialName: '',
    o2Percent: 21.7,
    pressureAtm: 1.0,
    velocityCmS: 20,
    flowDirection: 'Concurrent',
    gravity: '0g',
    thicknessMm: 0.32,
    questionText: '',
  });

  assert.equal(assessment.verdictLevel, 'CRITICAL_PROPAGATION');
  assert.equal(assessment.legacyComparison.legacyVfMmS, 3.25);
  assert.equal(assessment.closestExperimentalTrial?.record.id, 'MG-001');
  assert.equal(assessment.closestExperimentalTrial?.record.vfMmS, 1.75);
});

test('ranks liquid droplet FLEX cool-flame trials highest for n-Décane query', () => {
  const assessment = evaluateHabitatRisk(records, {
    materialKey: 'n-Décane (Goutte)',
    customMaterialName: '',
    o2Percent: 21,
    pressureAtm: 0.5,
    velocityCmS: 0,
    flowDirection: 'Stagnant',
    gravity: '0g',
    thicknessMm: null,
    questionText: '',
  });

  assert.equal(assessment.verdictLevel, 'COOL_FLAME_INSTABILITY');
  assert.equal(assessment.closestExperimentalTrial?.record.id, 'MG-011');
  const synthesis = buildDeterministicSynthesis(assessment, {
    materialKey: 'n-Décane (Goutte)',
    customMaterialName: '',
    o2Percent: 21,
    pressureAtm: 0.5,
    velocityCmS: 0,
    flowDirection: 'Stagnant',
    gravity: '0g',
    thicknessMm: null,
    questionText: '',
  }, 'en');
  assert.ok(synthesis.citedRecordIds.includes('MG-011'));
});

test('computeDomainChecks flags unknown material, 1/6g gravity, and 0.6 atm pressure gaps', () => {
  const query = parseNaturalLanguageQuestion(
    'Mon habitat lunaire utilise du tissu X, O₂ 34%, pression 0.6 atm, flux concurrent 15 cm/s'
  );
  const assessment = evaluateHabitatRisk(records, query, 'fr');
  const domain = computeDomainChecks(assessment, query, 'fr');

  assert.equal(domain.total, 4);
  assert.equal(domain.validCount, 1); // Only flow is within tested direction
  assert.equal(domain.checks.find((c) => c.key === 'material')?.ok, false);
  assert.equal(domain.checks.find((c) => c.key === 'pressure')?.ok, false);
  assert.equal(domain.checks.find((c) => c.key === 'gravity')?.ok, false);
  assert.equal(domain.checks.find((c) => c.key === 'flow')?.ok, true);
});

test('validates exact CSV category counts and droplet forced-flow domain limit', () => {
  const counts = new Map<string, number>();
  for (const r of records) {
    counts.set(r.rowType, (counts.get(r.rowType) ?? 0) + 1);
  }
  assert.equal(counts.get('Essai solide'), 10);
  assert.equal(counts.get('Essai goutte'), 10);
  assert.equal(counts.get('Référence LOI'), 12);
  assert.equal(counts.get('Scénario habitat'), 6);
  assert.equal(counts.get('Calculateur initial'), 1);

  const forcedFlowDroplet = {
    materialKey: 'n-Décane (Goutte)',
    customMaterialName: '',
    o2Percent: 21,
    pressureAtm: 0.5,
    velocityCmS: 15,
    flowDirection: 'Concurrent' as const,
    gravity: '0g' as const,
    thicknessMm: null,
    questionText: '',
  };
  const dropletAssessment = evaluateHabitatRisk(records, forcedFlowDroplet, 'en');
  const dropletDomain = computeDomainChecks(dropletAssessment, forcedFlowDroplet, 'en');
  assert.equal(dropletDomain.checks.find((c) => c.key === 'flow')?.ok, false);
  assert.ok(dropletAssessment.domainViolations.some((v) => v.includes('stagnant 0g')));
});

test('guards prepositions in custom fabric parser and generates clean English summary', () => {
  const parsed = parseNaturalLanguageQuestion(
    'My lunar habitat uses unknown fabric at 34% O2, 0.6 atm, 15 cm/s concurrent airflow'
  );
  assert.equal(parsed.materialKey, UNKNOWN_MATERIAL_KEY);
  assert.notEqual(parsed.customMaterialName.toLowerCase(), 'fabric at');
  assert.equal(parsed.o2Percent, 34);
  assert.equal(parsed.pressureAtm, 0.6);

  const summary = buildQuestionSummary(
    {
      materialKey: 'Tissu SIBAL (Coton/Verre)',
      customMaterialName: '',
      o2Percent: 21.7,
      pressureAtm: 1.0,
      velocityCmS: 20,
      flowDirection: 'Opposé',
      gravity: '0g',
      thicknessMm: 0.32,
      questionText: '',
    },
    'en'
  );
  assert.ok(summary.includes('SIBAL Fabric'));
  assert.ok(summary.includes('opposed airflow'));
  assert.ok(!summary.includes('Tissu'));
  assert.ok(!summary.includes('Opposé'));
});

test('low O2 alone does not grant safe verdict when pressure or gravity is out of domain', () => {
  const baseQuery = {
    materialKey: 'Tissu SIBAL (Coton/Verre)',
    customMaterialName: '',
    o2Percent: 14,
    pressureAtm: 1.0,
    velocityCmS: 20,
    flowDirection: 'Concurrent' as const,
    gravity: '0g' as const,
    thicknessMm: 0.32,
    questionText: '',
  };

  const inDomain = evaluateHabitatRisk(records, baseQuery, 'en');
  assert.equal(inDomain.verdictLevel, 'NO_PROPAGATION_OBSERVED');

  const lunar = evaluateHabitatRisk(records, { ...baseQuery, gravity: 'lunar' }, 'en');
  assert.equal(lunar.verdictLevel, 'OUT_OF_DOMAIN_UNKNOWN');

  const hypobaric = evaluateHabitatRisk(records, { ...baseQuery, pressureAtm: 0.6 }, 'en');
  assert.equal(hypobaric.verdictLevel, 'OUT_OF_DOMAIN_UNKNOWN');
});


