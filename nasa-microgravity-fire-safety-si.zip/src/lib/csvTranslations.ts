import type { Language } from '../types/fireSafety';

const EN_CSV_TEXT_MAP: Record<string, string> = {
  // verificationStatus
  'Chiffres à rapprocher du fichier NASA': 'Cross-check figures against NASA source file',
  'Hypothèse de seuil : vérifier publication': 'Threshold hypothesis: verify in publication',
  'Simulation non validée': 'Unvalidated simulation',
  'Calcul interne (non validé)': 'Internal calculation (unvalidated)',

  // validityDomain
  'Conditions ponctuelles de cet essai uniquement': 'Point conditions of this specific trial only',
  'Résultats dépendants du diamètre, du diluant et de l’historique d’allumage':
    'Results depend on droplet diameter, diluent, and ignition history',
  'Application limitée à la géométrie, O₂, P et flux de référence':
    'Limited to reference geometry, O₂, pressure, and airflow',
  'Conditions de référence à vérifier (géométrie / pression / atmosphère)':
    'Reference conditions unverified (geometry / pressure / atmosphere)',
  'Hors domaine (pression différente)': 'Out of domain (pressure mismatch)',
  'Hypothèse de quenching, non garantie': 'Quenching assumption, not guaranteed',
  'Comparaison de concentration seule': 'Concentration comparison only',
  'Référence liquide et mécanisme différents des solides':
    'Liquid fuel mechanism differs from solid flammability',
  'Aucune validation prospective démontrée': 'No prospective validation demonstrated',

  // dataNature
  'Donnée expérimentale transcrite': 'Transcribed experimental data',
  'Seuil de la matrice initiale (non certifié)': 'Initial matrix threshold (uncertified)',
  'Scénario de calcul, non observation': 'Calculated scenario, not an observation',
  'Paramètres + formules héritées': 'Parameters + legacy spreadsheet formulas',

  // indicatorNature
  'Mesures expérimentales rapportées': 'Reported experimental measurements',
  'Paramètres tabulés, à justifier par publication':
    'Tabulated parameters; cite primary publication',
  'Comparaison indicative avec seuil tabulé': 'Indicative comparison to tabulated threshold',
  'Vf = équation ad hoc non calibrée': 'Vf = uncalibrated ad hoc equation',

  // scientificAlert
  'Valeur reprise du classeur fourni; retrouver la ligne exacte dans la table NASA avant validation.':
    'Value transcribed from workbook; match exact row in NASA table before validation.',
  'Blowoff à fort débit : un seuil U_min seul ne décrit pas toutes les extinctions.':
    'High-velocity blowoff: a single U_min threshold cannot capture upper extinction limits.',
  'Le commentaire cite un changement de débit à 8 cm/s : ne pas assimiler Vf et U à la même phase sans journal temporel.':
    'Note cites an airflow change to 8 cm/s: do not pair Vf and U without time-series logs.',
  'Correspondance à la matrice Tige PMMA à contrôler (rayon vs dimensions indiquées).':
    'Check PMMA Rod matrix match (radius vs. listed sample dimensions).',
  '« Ininflammable » décrit cet essai; pas une certification pour toutes les atmosphères.':
    '"Non-flammable" describes this specific trial only; not a blanket atmospheric certification.',
  'd_ext,hot > d0 dans la source : vérifier interprétation / transcription (gonflement possible, non déduit ici).':
    'd_ext,hot > d0 in source: verify transcription/interpretation (possible droplet swelling).',
  'Flamme froide indiquée dans le classeur; confirmer d0, extinction et K sur la table FLEX originale.':
    'Cool flame noted in workbook; verify d0, extinction diameters, and K in original FLEX table.',
  'Absence de flamme froide rapportée pour ce test, ne pas inférer un régime universel.':
    'No cool flame reported in this trial; do not generalize as universal behavior.',
  'Seuils de la matrice d’origine non établis ici comme limites universelles ou certifiées.':
    'Original matrix thresholds are indicative only, not established universal or certified limits.',
  'Plage géométrique à recouper : diamètre ou rayon non explicité.':
    'Verify geometric range: diameter vs. radius not explicitly specified.',
  'Observation d’absence de propagation à O₂=22,2 % n’établit pas nécessairement un LOI exact de 22,2 %.':
    'Observed non-propagation at 22.2% O₂ does not establish an exact 22.2% LOI.',
  'Ne pas traiter ce seuil O₂ de goutte comme un LOI normalisé interchangeable avec celui des solides; U_min=0 non transposable.':
    'Do not treat this droplet O₂ limit as a standardized solid LOI; U_min=0 is non-transferable.',
  'Épaisseur 1 cm différente des plaques PMMA 1–5 mm ; éviter l’amalgame.':
    '1 cm cast thickness differs from 1–5 mm PMMA plates; do not conflate thresholds.',
  'Scénario hypothétique; aucune validation expérimentale aux paramètres exacts fournie.':
    'Hypothetical scenario; no experimental validation provided at these exact parameters.',
  'P=0,6 atm vs référence SIBAL à 1 atm : extrapolation hors des conditions de la matrice.':
    'P=0.6 atm vs. 1 atm SIBAL reference: extrapolates outside matrix test conditions.',
  'Faible ventilation peut éteindre certaines flammes mais pas toutes ; augmentation soudaine de U peut relancer le feu.':
    'Low ventilation may quench some flames but not all; a sudden rise in airflow U can re-ignite fire.',
  'Ne pas généraliser « ininflammable » à toutes géométries et atmosphères; seuil Nomex à recouper.':
    'Do not generalize "non-flammable" across all geometries/atmospheres; cross-check Nomex limit.',
  'Flamme froide FLEX possible, jamais garantie : diamètre initial, diluant et séquence d’ignition absents.':
    'FLEX cool flame possible, never guaranteed: initial diameter, diluent, and ignition sequence missing.',
  'O₂ sous le seuil tabulé n’est pas une preuve suffisante d’absence de feu; protocole non précisé.':
    'O₂ below tabulated threshold is insufficient proof of non-flammability; protocol unspecified.',
  'Vf calculée=3,25 mm/s à U=20 alors que Saffire-1 rapporte 1,75 mm/s à U=20 et O₂=21,7 %; comparaison illustrative, conditions O₂ non identiques.':
    'Calculated Vf=3.25 mm/s at U=20 vs. Saffire-1 reporting 1.75 mm/s at U=20 and 21.7% O₂ (uncalibrated formula).',

  // initialObservation
  'Quasi-statique, limite de pyrolyse atteinte': 'Quasi-steady spread, pyrolysis limit reached',
  'Propagation quasi-statique plus rapide avec U=25cm/s': 'Faster quasi-steady spread at U=25 cm/s',
  'Échantillon étroit, effet de bordure': 'Narrow sample, edge effects present',
  'Flamme non-croissante, arrêt après 15 min': 'Non-growing flame, self-stopped after 15 min',
  'Extinction radiative à basse vitesse (Quench)': 'Low-velocity radiative extinction (Quench)',
  'Extinction par soufflage (Blowoff)': 'High-velocity blowoff extinction',
  'Propagation lente puis extinction à U=8cm/s': 'Slow spread then extinction at U=8 cm/s',
  'Extinction à pot 0.35 (faible flux)': 'Extinction at low airflow (pot 0.35)',
  'Extinction par quenching à faible débit': 'Low-flow radiative quenching',
  'Ininflammable (Extinction immédiate)': 'Non-flammable (immediate extinction)',
  'Régime de flamme froide indiqué tel quel dans le fichier initial.':
    'Cool-flame regime transcribed from original workbook.',
  'Valeurs recopiées, non reclassées comme mesures expérimentales directes.':
    'Transcribed values, not classified as direct experimental measurements.',
  'Scénario repris de la zone comparative du classeur.':
    'Scenario transcribed from workbook comparative table.',
  'B13=16,4 % ; B14=4,6 points ; B15=2,5 cm/s ; B16=propagation active ; B17=3,25 mm/s ; B18=risque élevé (résultats de la logique d’origine).':
    'B13=16.4%; B14=4.6 pts; B15=2.5 cm/s; B16=active spread; B17=3.25 mm/s; B18=high risk (legacy spreadsheet output).',

  // legacyModelResult
  '🔴 PROPAGATION ACTIVE [modèle initial, non validé]': '🔴 ACTIVE SPREAD [legacy, unvalidated]',
  '🟢 EXTINCTION RADIATIVE [modèle initial, non validé]': '🟢 RADIATIVE QUENCH [legacy, unvalidated]',
  '🟢 ININFLAMMABLE [modèle initial, non validé]': '🟢 NON-FLAMMABLE [legacy, unvalidated]',
  '🟠 FLAMME FROIDE [modèle initial, non validé]': '🟠 COOL FLAME [legacy, unvalidated]',
  '🔴 RISQUE ÉLEVÉ (modèle hérité, non validé)': '🔴 HIGH RISK (legacy, unvalidated)',

  // geometry
  'Non documentée dans ce scénario': 'Not documented in scenario',
  'Solide / tissu (échantillon)': 'Solid / fabric sample',
  'Solide / PMMA': 'Solid / PMMA',
  'Goutte de combustible liquide': 'Liquid fuel droplet',
  'Voir conditions de référence': 'See reference conditions',
  'Plaque fine (0.32 mm)': 'Thin sheet (0.32 mm)',
};

export function translateCsvField(raw: string, language: Language): string {
  if (!raw || language === 'fr') return raw;
  return EN_CSV_TEXT_MAP[raw] ?? raw;
}

export function translateSourceId(raw: string, language: Language): string {
  if (!raw || language === 'fr') return raw;
  if (raw.startsWith('Seuil ')) return raw.replace('Seuil ', 'Threshold ');
  if (raw === 'Réglage utilisateur (défaut)') return 'User Default Setting';
  if (raw.startsWith('Scénario ')) {
    return raw
      .replace('Scénario ', 'Scenario ')
      .replace('Air Standard ISS/Terre', 'Standard ISS/Earth Air')
      .replace('Atmosphere SEA (Exploration)', 'SEA Exploration Atmosphere')
      .replace('Extinction / Ventilation Basse', 'Low-Ventilation Quench')
      .replace('Protection Nomex (Tissu Ignifuge)', 'Nomex Flame-Resistant Protection')
      .replace('Hydrocarbure Liquid (n-Décane)', 'Liquid Hydrocarbon (n-Decane)')
      .replace('Atmosphère Appauvrie (Hypoxique)', 'Hypoxic Depleted Atmosphere');
  }
  return raw;
}
