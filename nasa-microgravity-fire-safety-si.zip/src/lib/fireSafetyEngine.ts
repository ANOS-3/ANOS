import { translateCsvField } from './csvTranslations';
import type {
  FlowDirection,
  GravityEnvironment,
  HabitatQuery,
  HonestAssessment,
  HonestVerdictLevel,
  Language,
  LegacyModelComparison,
  MicrogravityRecord,
  RankedEvidence,
  SISynthesis,
} from '../types/fireSafety';

export const UNKNOWN_MATERIAL_KEY = 'UNKNOWN_CUSTOM';

export interface MaterialCatalogEntry {
  loiKey: string;
  labelEn: string;
  labelFr: string;
  category: 'solid' | 'droplet';
  family: string;
  referenceNote: string;
}

export const MATERIAL_CATALOG: MaterialCatalogEntry[] = [
  {
    loiKey: 'Tissu SIBAL (Coton/Verre)',
    labelEn: 'SIBAL Fabric (75% Cotton / 25% Fiberglass)',
    labelFr: 'Tissu SIBAL (75% Coton / 25% Verre)',
    category: 'solid',
    family: 'SIBAL (coton / fibre de verre)',
    referenceNote: '0.32 mm, Saffire-1/2/3 & BASS-II',
  },
  {
    loiKey: 'Tissu Nomex III',
    labelEn: 'Nomex III Flame-Resistant Fabric',
    labelFr: 'Tissu Nomex III (Ignifuge)',
    category: 'solid',
    family: 'Nomex III',
    referenceNote: '0.4 mm, BASS-II (F1)',
  },
  {
    loiKey: 'Tissu Coton Pur',
    labelEn: 'Pure Cotton Fabric',
    labelFr: 'Tissu Coton Pur',
    category: 'solid',
    family: 'Coton',
    referenceNote: 'BASS-II comparative reference',
  },
  {
    loiKey: 'Silicone (0.25 - 0.61 mm)',
    labelEn: 'Silicone Sheet (0.25–0.61 mm)',
    labelFr: 'Silicone (0.25–0.61 mm)',
    category: 'solid',
    family: 'Silicone',
    referenceNote: 'BASS-II / NASA-STD-6001 Test 1 marginal',
  },
  {
    loiKey: 'Plaque fine PMMA (0.1-0.4 mm)',
    labelEn: 'Thin PMMA Film (0.1–0.4 mm)',
    labelFr: 'Plaque fine PMMA (0.1–0.4 mm)',
    category: 'solid',
    family: 'PMMA (acrylique)',
    referenceNote: 'BASS-II (B13), Opposed flow',
  },
  {
    loiKey: 'Plaque PMMA Épaisse (1-5 mm)',
    labelEn: 'Thick PMMA Slab (1–5 mm)',
    labelFr: 'Plaque PMMA Épaisse (1–5 mm)',
    category: 'solid',
    family: 'PMMA (acrylique)',
    referenceNote: 'BASS-II (M18), Opposed flow',
  },
  {
    loiKey: 'PMMA (Cast PMMA)',
    labelEn: 'Cast PMMA Thick Plate (10 mm)',
    labelFr: 'Plaque PMMA Cast Épaisse (10 mm)',
    category: 'solid',
    family: 'PMMA (acrylique)',
    referenceNote: 'Saffire-2 Sample 9',
  },
  {
    loiKey: 'Tige PMMA (6.35 mm - 12.7 mm)',
    labelEn: 'PMMA Rod (6.35–12.7 mm)',
    labelFr: 'Tige PMMA (6.35–12.7 mm)',
    category: 'solid',
    family: 'PMMA (acrylique)',
    referenceNote: 'BASS-II (P1), Stagnation / Opposed',
  },
  {
    loiKey: 'n-Décane (Goutte)',
    labelEn: 'n-Decane (Liquid Droplet)',
    labelFr: 'n-Décane (Goutte liquide)',
    category: 'droplet',
    family: 'n-Décane',
    referenceNote: 'FLEX ISS, 0.5 atm, Cool flame',
  },
  {
    loiKey: 'n-Heptane (Goutte)',
    labelEn: 'n-Heptane (Liquid Droplet)',
    labelFr: 'n-Heptane (Goutte liquide)',
    category: 'droplet',
    family: 'n-Heptane',
    referenceNote: 'FLEX ISS, 1.0 atm, Cool flame',
  },
  {
    loiKey: 'n-Octane (Goutte)',
    labelEn: 'n-Octane (Liquid Droplet)',
    labelFr: 'n-Octane (Goutte liquide)',
    category: 'droplet',
    family: 'n-Octane',
    referenceNote: 'FLEX ISS, 1.0 atm, Cool flame',
  },
  {
    loiKey: 'Méthanol (Goutte)',
    labelEn: 'Methanol (Liquid Droplet)',
    labelFr: 'Méthanol (Goutte liquide)',
    category: 'droplet',
    family: 'Méthanol',
    referenceNote: 'FLEX ISS, 1.0 atm, Diffusive extinction',
  },
];

export function detectLanguageFromText(text: string): Language {
  const lower = text.toLowerCase();
  const frMarkers = [
    'mon ',
    'quel ',
    'risque',
    'incendie',
    'tissu',
    'flux',
    'lunaire',
    'utilise',
    'air',
    'pression',
    'coton',
    'flamme',
    'habitat',
    'avec ',
    'dans ',
  ];
  let frScore = 0;
  for (const m of frMarkers) {
    if (lower.includes(m)) frScore += 1;
  }
  const enMarkers = ['my ', 'what ', 'fire risk', 'fabric', 'airflow', 'lunar', 'oxygen', 'pressure', 'using '];
  let enScore = 0;
  for (const m of enMarkers) {
    if (lower.includes(m)) enScore += 1;
  }
  return frScore >= enScore && frScore > 0 ? 'fr' : 'en';
}

/**
 * Extracts habitat simulation parameters from a natural-language question
 * such as: "Mon habitat lunaire utilise du tissu X, O₂ 34%, flux d’air concurrent 15 cm/s. Quel est le risque incendie ?"
 */
export function parseNaturalLanguageQuestion(
  text: string,
  fallback?: Partial<HabitatQuery>
): HabitatQuery {
  const clean = text.trim();
  const lower = clean.toLowerCase();

  // Gravity detection
  let gravity: GravityEnvironment = fallback?.gravity ?? '0g';
  if (/lunai?r|lune|moon|artemis|1\/6\s*g/i.test(lower)) {
    gravity = 'lunar';
  } else if (/mars|martien|martian|0\.38\s*g/i.test(lower)) {
    gravity = 'mars';
  } else if (/micrograv|0\s*g|iss|saffire|bass|orbite/i.test(lower)) {
    gravity = '0g';
  }

  // Flow direction detection
  let flowDirection: FlowDirection = fallback?.flowDirection ?? 'Concurrent';
  if (/oppos[eé]|counter[-\s]?flow|against/i.test(lower)) {
    flowDirection = 'Opposé';
  } else if (/stagnant|quiescent|sans ventilation|no flow|still air/i.test(lower)) {
    flowDirection = 'Stagnant';
  } else if (/concurrent|co[-\s]?flow/i.test(lower)) {
    flowDirection = 'Concurrent';
  }

  // O2 % extraction (handles "O₂ 28%", "O2 = 34 %", "21.7% O2", "oxygen 26%")
  let o2Percent = fallback?.o2Percent ?? 21;
  const o2MatchPrefix = clean.match(/(?:o[₂2]|oxyg[eè]ne?)\s*(?:[:=àde\s]+)\s*(\d+(?:[.,]\d+)?)\s*%/i);
  const o2MatchSuffix = clean.match(/(\d+(?:[.,]\d+)?)\s*%\s*(?:d['’]?\s*)?(?:o[₂2]|oxyg[eè]ne?)/i);
  const o2MatchGeneric = clean.match(/(\d+(?:[.,]\d+)?)\s*%/);
  const rawO2 = o2MatchPrefix?.[1] ?? o2MatchSuffix?.[1] ?? o2MatchGeneric?.[1];
  if (rawO2) {
    const parsed = Number(rawO2.replace(',', '.'));
    if (Number.isFinite(parsed) && parsed > 0 && parsed <= 100) {
      o2Percent = parsed;
    }
  }

  // Pressure extraction (atm or kPa)
  let pressureAtm = fallback?.pressureAtm ?? (gravity === 'lunar' && o2Percent >= 30 ? 0.6 : 1.0);
  const atmMatch = clean.match(/(\d+(?:[.,]\d+)?)\s*atm/i);
  const kpaMatch = clean.match(/(\d+(?:[.,]\d+)?)\s*kpa/i);
  if (atmMatch?.[1]) {
    const p = Number(atmMatch[1].replace(',', '.'));
    if (Number.isFinite(p) && p > 0 && p <= 5) pressureAtm = p;
  } else if (kpaMatch?.[1]) {
    const kpa = Number(kpaMatch[1].replace(',', '.'));
    if (Number.isFinite(kpa) && kpa > 0) pressureAtm = Number((kpa / 101.325).toFixed(3));
  }

  // Airflow velocity U extraction (cm/s)
  let velocityCmS = fallback?.velocityCmS ?? (flowDirection === 'Stagnant' ? 0 : 20);
  const velMatch = clean.match(/(\d+(?:[.,]\d+)?)\s*cm\s*\/\s*s/i);
  if (velMatch?.[1]) {
    const v = Number(velMatch[1].replace(',', '.'));
    if (Number.isFinite(v) && v >= 0 && v <= 200) velocityCmS = v;
  }

  // Material extraction
  let materialKey = UNKNOWN_MATERIAL_KEY;
  let customMaterialName = '';

  if (/sibal/i.test(lower)) {
    materialKey = 'Tissu SIBAL (Coton/Verre)';
  } else if (/nomex/i.test(lower)) {
    materialKey = 'Tissu Nomex III';
  } else if (/coton\s*pur|pure\s*cotton|\bcoton\b|\bcotton\b/i.test(lower)) {
    materialKey = 'Tissu Coton Pur';
  } else if (/silicone/i.test(lower)) {
    materialKey = 'Silicone (0.25 - 0.61 mm)';
  } else if (/cast\s*pmma|pmma\s*(?:cast|10\s*mm|1\s*cm)/i.test(lower)) {
    materialKey = 'PMMA (Cast PMMA)';
  } else if (/tige\s*pmma|pmma\s*rod/i.test(lower)) {
    materialKey = 'Tige PMMA (6.35 mm - 12.7 mm)';
  } else if (/film\s*pmma|fine\s*pmma|thin\s*pmma/i.test(lower)) {
    materialKey = 'Plaque fine PMMA (0.1-0.4 mm)';
  } else if (/pmma|acrylique|acrylic|plexiglas/i.test(lower)) {
    materialKey = 'Plaque PMMA Épaisse (1-5 mm)';
  } else if (/d[eé]cane|decane/i.test(lower)) {
    materialKey = 'n-Décane (Goutte)';
  } else if (/heptane/i.test(lower)) {
    materialKey = 'n-Heptane (Goutte)';
  } else if (/octane/i.test(lower)) {
    materialKey = 'n-Octane (Goutte)';
  } else if (/m[eé]thanol|methanol/i.test(lower)) {
    materialKey = 'Méthanol (Goutte)';
  } else {
    // Capture custom fabric/material phrase like "tissu X", "fabric Kapton", "matériau Kevlar"
    const customMatch = clean.match(
      /(?:tissu|fabric|mat[eé]riau|material|textile|polymer[e]?)\s+([A-Za-z0-9À-ÿ\-_+/.]{1,32})/i
    );
    const stopWords = new Set([
      'at',
      'in',
      'with',
      'using',
      'for',
      'of',
      'on',
      'and',
      'or',
      'à',
      'avec',
      'dans',
      'en',
      'de',
      'du',
      'pour',
      'sous',
      'sur',
      'et',
      'ou',
    ]);
    if (customMatch?.[1] && !stopWords.has(customMatch[1].toLowerCase())) {
      customMaterialName = `${customMatch[0].trim()}`;
    } else if (fallback?.materialKey && fallback.materialKey !== UNKNOWN_MATERIAL_KEY) {
      materialKey = fallback.materialKey;
      customMaterialName = fallback.customMaterialName ?? '';
    } else if (fallback?.customMaterialName) {
      customMaterialName = fallback.customMaterialName;
    } else {
      customMaterialName = detectLanguageFromText(clean) === 'fr' ? 'Tissu X' : 'Fabric X';
    }
  }

  return {
    materialKey,
    customMaterialName,
    o2Percent,
    pressureAtm,
    velocityCmS,
    flowDirection,
    gravity,
    thicknessMm: fallback?.thicknessMm ?? null,
    questionText: clean,
  };
}

function computeLegacyModel(
  records: MicrogravityRecord[],
  query: HabitatQuery,
  language: Language = 'en'
): LegacyModelComparison {
  const isFr = language === 'fr';
  const loiRecord = records.find(
    (r) => r.rowType === 'Référence LOI' && r.loiKey === query.materialKey
  );

  if (!loiRecord || loiRecord.loiO2Threshold === null || loiRecord.uMinCmS === null) {
    return {
      legacyStatus: 'VLOOKUP ERROR (#N/A)',
      legacyRiskLabel: isFr
        ? 'Non applicable (matériau absent de Matrice_LOI_Limites)'
        : 'Not applicable (material absent from Matrice_LOI_Limites)',
      legacyVfMmS: null,
      legacyLoiUsed: null,
      legacyUMinUsed: null,
      divergenceWarnings: [
        isFr
          ? 'Le calculateur Excel historique échoue (#N/A) dès qu’un matériau n’est pas dans les 12 clés exactes de Matrice_LOI_Limites.'
          : 'The legacy Excel calculator returns a #N/A lookup error for any material outside the 12 exact keys in Matrice_LOI_Limites.',
      ],
    };
  }

  const loi = loiRecord.loiO2Threshold;
  const uMin = loiRecord.uMinCmS;
  const isDroplet = loiRecord.loiKey.includes('Goutte');

  let legacyStatus = isFr
    ? 'Propagation Active (Flamme Chaude)'
    : 'Active Propagation (Hot Flame)';
  let legacyRiskLabel = isFr
    ? '🔴 RISQUE ÉLEVÉ - COMBUSTION ACTIVE'
    : '🔴 HIGH RISK - ACTIVE COMBUSTION';
  let legacyVfMmS: number | null = 0.2;

  if (query.o2Percent < loi) {
    legacyStatus = isFr ? 'Extinction (O2 < LOI)' : 'Extinction (O2 < LOI)';
    legacyRiskLabel = isFr
      ? '🟢 RISQUE FAIBLE - EXTINCTION AUTOMATIQUE'
      : '🟢 LOW RISK - AUTOMATIC EXTINCTION';
    legacyVfMmS = 0;
  } else if (query.velocityCmS < uMin) {
    legacyStatus = isFr
      ? 'Extinction Radiative (Ventilation insuffisante)'
      : 'Radiative Extinction (Insufficient Ventilation)';
    legacyRiskLabel = isFr
      ? '🟢 RISQUE FAIBLE - EXTINCTION AUTOMATIQUE'
      : '🟢 LOW RISK - AUTOMATIC EXTINCTION';
    legacyVfMmS = 0;
  } else if (isDroplet && query.o2Percent <= 21) {
    legacyStatus = isFr
      ? 'Combustion Flamme Froide Possible'
      : 'Possible Cool-Flame Combustion';
    legacyRiskLabel = isFr
      ? '🟠 RISQUE MODÉRÉ - FLAMME FROIDE'
      : '🟠 MODERATE RISK - COOL FLAME';
    legacyVfMmS = 0.2;
  } else {
    if (query.materialKey === 'Tissu SIBAL (Coton/Verre)') {
      legacyVfMmS = Number((0.1 * (query.velocityCmS - uMin) + 1.5).toFixed(2));
    } else if (query.materialKey.includes('PMMA')) {
      legacyVfMmS = Number((0.05 * query.velocityCmS + 0.5).toFixed(2));
    } else {
      legacyVfMmS = 0.2;
    }
  }

  const divergenceWarnings: string[] = [];
  if (query.materialKey === 'Tissu SIBAL (Coton/Verre)' && query.velocityCmS >= uMin && query.o2Percent >= loi) {
    divergenceWarnings.push(
      isFr
        ? `Audit MG-039 : La formule héritée prédit Vf = ${legacyVfMmS} mm/s (ex. 3,25 mm/s à U=20), alors que Saffire-1 (MG-001) a mesuré 1,75 mm/s à O₂=21,7 %, U=20 cm/s (équation ad hoc sans dépendance à O₂ ou P).`
        : `MG-039 Audit: The legacy formula predicts Vf = ${legacyVfMmS} mm/s (e.g. 3.25 mm/s at U=20), whereas Saffire-1 (MG-001) measured 1.75 mm/s at 21.7% O₂, U=20 cm/s (uncalibrated ad hoc equation).`
    );
  }
  if (query.pressureAtm !== 1 && !isDroplet) {
    divergenceWarnings.push(
      isFr
        ? `Audit MG-034 : Le modèle hérité ignore totalement la pression (P=${query.pressureAtm} atm vs référence 1,0 atm).`
        : `MG-034 Audit: The legacy model completely ignores pressure (P=${query.pressureAtm} atm vs 1.0 atm reference).`
    );
  }
  if (query.velocityCmS < uMin && query.o2Percent >= loi) {
    divergenceWarnings.push(
      isFr
        ? `Audit MG-035 : Le modèle hérité classe « Extinction automatique » dès que U < ${uMin} cm/s, masquant la reprise de feu dès qu’un ventilateur ou mouvement d’équipage augmente U.`
        : `MG-035 Audit: The legacy model labels U < ${uMin} cm/s as "Automatic Extinction", masking rapid re-ignition if a fan or crew motion raises airflow.`
    );
  }
  if (query.velocityCmS >= 35) {
    divergenceWarnings.push(
      isFr
        ? `Audit MG-006 : Le modèle hérité ignore le soufflage (blowoff) à haute vitesse observé dans BASS-II (MG-006 à U=47 cm/s).`
        : `MG-006 Audit: The legacy model ignores high-velocity blowoff observed in BASS-II (MG-006 at U=47 cm/s).`
    );
  }

  return {
    legacyStatus,
    legacyRiskLabel,
    legacyVfMmS,
    legacyLoiUsed: loi,
    legacyUMinUsed: uMin,
    divergenceWarnings,
  };
}

export function rankEvidence(
  records: MicrogravityRecord[],
  query: HabitatQuery
): RankedEvidence[] {
  const catalogMatch = MATERIAL_CATALOG.find((m) => m.loiKey === query.materialKey);
  const queryIsDroplet = catalogMatch?.category === 'droplet';
  const queryPO2 = (query.o2Percent / 100) * query.pressureAtm;

  const ranked = records.map((record): RankedEvidence => {
    let score = 0;
    const matchReasons: string[] = [];
    const mismatchFlags: string[] = [];

    const recordIsDroplet =
      record.rowType === 'Essai goutte' || record.loiKey.includes('Goutte');
    const isExperimental =
      record.rowType === 'Essai solide' || record.rowType === 'Essai goutte';

    // 1. Material alignment (up to 40 pts)
    if (query.materialKey !== UNKNOWN_MATERIAL_KEY && record.loiKey === query.materialKey) {
      score += 40;
      matchReasons.push(`Exact material key (${record.loiKey})`);
    } else if (
      query.materialKey !== UNKNOWN_MATERIAL_KEY &&
      catalogMatch &&
      record.materialFamily === catalogMatch.family
    ) {
      score += 28;
      matchReasons.push(`Same material family (${record.materialFamily})`);
    } else if (query.materialKey === UNKNOWN_MATERIAL_KEY) {
      const customLower = query.customMaterialName.toLowerCase();
      if (
        (customLower.includes('tissu') || customLower.includes('fabric') || customLower.includes('textile')) &&
        (record.materialFamily.includes('SIBAL') ||
          record.materialFamily.includes('Nomex') ||
          record.materialFamily.includes('Coton'))
      ) {
        score += 22;
        matchReasons.push(`Textile analog (${record.materialOriginal})`);
      } else if (!recordIsDroplet && record.rowType === 'Essai solide') {
        score += 12;
        matchReasons.push('Solid combustion reference');
      }
      mismatchFlags.push('Unknown target material (analog only)');
    } else if (queryIsDroplet !== recordIsDroplet) {
      mismatchFlags.push('Phase mismatch (solid vs liquid droplet)');
    }

    // 2. O2 / pO2 proximity (up to 25 pts)
    const refO2 = record.o2Percent ?? record.loiO2Threshold;
    if (refO2 !== null) {
      const diffO2 = Math.abs(query.o2Percent - refO2);
      const o2Score = Math.max(0, 20 - diffO2 * 1.4);
      score += o2Score;
      if (diffO2 <= 2.5) {
        matchReasons.push(`Close O₂ (${refO2}% vs ${query.o2Percent}%)`);
      } else if (diffO2 >= 8) {
        mismatchFlags.push(`O₂ gap (${refO2}% vs ${query.o2Percent}%)`);
      }
    }
    if (record.pO2Atm !== null) {
      const diffPO2 = Math.abs(queryPO2 - record.pO2Atm);
      score += Math.max(0, 5 - diffPO2 * 40);
    }

    // 3. Airflow velocity U proximity (up to 15 pts)
    const refU = record.velocityCmS ?? record.uMinCmS;
    if (refU !== null) {
      const diffU = Math.abs(query.velocityCmS - refU);
      score += Math.max(0, 15 - diffU * 0.6);
      if (diffU <= 5) {
        matchReasons.push(`Close airflow (${refU} cm/s)`);
      }
    }

    // 4. Pressure proximity (up to 10 pts)
    if (record.pressureAtm !== null) {
      const diffP = Math.abs(query.pressureAtm - record.pressureAtm);
      score += Math.max(0, 10 - diffP * 20);
      if (diffP > 0.15) {
        mismatchFlags.push(`Pressure mismatch (${record.pressureAtm} atm vs ${query.pressureAtm} atm)`);
      }
    }

    // 5. Flow direction & Experimental evidence weight (up to 10 pts)
    if (record.flowDirection && record.flowDirection === query.flowDirection) {
      score += 6;
      matchReasons.push(`Same flow (${record.flowDirection})`);
    } else if (
      record.flowDirection &&
      record.flowDirection !== query.flowDirection &&
      !recordIsDroplet
    ) {
      mismatchFlags.push(`Flow mismatch (${record.flowDirection} vs ${query.flowDirection})`);
    }

    if (isExperimental) {
      score += 6;
      matchReasons.push('Direct NASA flight experiment');
    } else if (record.rowType === 'Référence LOI') {
      score += 2;
    } else {
      score -= 4;
      mismatchFlags.push('Unvalidated legacy simulation row');
    }

    const boundedScore = Math.max(0, Math.min(100, Math.round(score)));
    return {
      record,
      similarityScore: boundedScore,
      matchReasons,
      mismatchFlags,
    };
  });

  ranked.sort((a, b) => b.similarityScore - a.similarityScore);
  return ranked;
}

export function evaluateHabitatRisk(
  records: MicrogravityRecord[],
  query: HabitatQuery,
  language: Language = 'en'
): HonestAssessment {
  const isFr = language === 'fr';
  const pO2Atm = Number(((query.o2Percent / 100) * query.pressureAtm).toFixed(4));
  const isKnownMaterial = query.materialKey !== UNKNOWN_MATERIAL_KEY;
  const catalogEntry = MATERIAL_CATALOG.find((m) => m.loiKey === query.materialKey);
  const isDropletMaterial = catalogEntry?.category === 'droplet';

  const matchedLoiRecord = isKnownMaterial
    ? records.find((r) => r.rowType === 'Référence LOI' && r.loiKey === query.materialKey) ?? null
    : null;

  const loiO2Threshold = matchedLoiRecord?.loiO2Threshold ?? null;
  const uMinThreshold = matchedLoiRecord?.uMinCmS ?? null;
  const deltaO2Pts =
    loiO2Threshold !== null ? Number((query.o2Percent - loiO2Threshold).toFixed(2)) : null;

  const rankedEvidence = rankEvidence(records, query);
  const closestExperimentalTrial =
    rankedEvidence.find(
      (item) =>
        item.record.rowType === 'Essai solide' || item.record.rowType === 'Essai goutte'
    ) ?? null;

  const domainViolations: string[] = [];
  const epistemicCaveats: string[] = [];

  if (!isKnownMaterial) {
    domainViolations.push(
      isFr
        ? `Le matériau « ${query.customMaterialName || 'Personnalisé'} » est absent des 39 fiches NASA microgravité et de la matrice LOI (12 matériaux).`
        : `Material "${query.customMaterialName || 'Custom'}" is absent from the 39-record NASA microgravity database and the 12-material LOI matrix.`
    );
    epistemicCaveats.push(
      isFr
        ? 'Impossible d’attribuer un LOI certifié ou une vitesse Vf à un tissu non caractérisé. Les données NASA ci-dessous utilisent SIBAL (LOI ~16,4 %), Coton Pur (~16,0 %) et Nomex III (non-propagation à 22,2 %) uniquement comme bornes comparatives.'
        : 'Cannot assign a verified LOI or flame spread rate to an uncharacterized fabric. NASA data below uses SIBAL (LOI ~16.4%), Pure Cotton (~16.0%), and Nomex III (no spread observed at 22.2%) only as non-binding reference bounds.'
    );
  }

  if (query.gravity !== '0g') {
    const gLabel =
      query.gravity === 'lunar'
        ? isFr
          ? 'Gravité partielle lunaire (1/6g)'
          : 'Lunar partial gravity (1/6g)'
        : isFr
          ? 'Gravité partielle martienne (0.38g)'
          : 'Martian partial gravity (0.38g)';
    domainViolations.push(
      isFr
        ? `${gLabel} est hors du domaine expérimental 0g de Saffire, BASS-II et FLEX.`
        : `${gLabel} is outside the 0g microgravity experimental domain of Saffire, BASS-II, and FLEX.`
    );
    epistemicCaveats.push(
      isFr
        ? 'La gravité partielle (1/6g ou 0.38g) introduit une convection naturelle faible qui modifie la propagation et peut élargir le domaine d’inflammabilité par rapport à 0g pur.'
        : 'Partial gravity (1/6g or 0.38g) introduces weak buoyant convection that alters flame spread and can widen flammability limits compared to pure 0g.'
    );
  }

  // Pressure reference check
  const refPressure =
    query.materialKey === 'n-Décane (Goutte)' ? 0.5 : 1.0;
  if (Math.abs(query.pressureAtm - refPressure) > 0.1) {
    domainViolations.push(
      isFr
        ? `La pression habitat (${query.pressureAtm} atm) diverge de la référence ${refPressure} atm des seuils ${matchedLoiRecord?.mission ?? 'NASA BASS-II / Saffire'}.`
        : `Habitat pressure (${query.pressureAtm} atm) diverges from the ${refPressure} atm reference used in ${matchedLoiRecord?.mission ?? 'NASA BASS-II / Saffire'} thresholds.`
    );
    if (query.o2Percent >= 26 && query.pressureAtm < 0.8) {
      epistemicCaveats.push(
        isFr
          ? `Effet atmosphère d’exploration (voir MG-034) : un taux d’O₂ élevé (${query.o2Percent}%) à pression réduite (${query.pressureAtm} atm, pO₂=${pO2Atm} atm) réduit la capacité thermique par mole d’O₂ et accroît généralement le risque de propagation vs 21% O₂ à 1 atm.`
          : `Exploration atmosphere effect (see MG-034): elevated O₂ (${query.o2Percent}%) at reduced pressure (${query.pressureAtm} atm, pO₂=${pO2Atm} atm) decreases heat capacity per unit O₂ mole and typically increases fire spread risk relative to 21% O₂ at 1 atm.`
      );
    }
  }

  if (query.flowDirection === 'Concurrent' && query.materialKey.includes('PMMA') && !query.materialKey.includes('Cast')) {
    domainViolations.push(
      isFr
        ? 'Les seuils BASS-II pour PMMA ont été mesurés principalement en flux Opposé ou Stagnation, alors que le flux Concurrent est plus sévère.'
        : 'BASS-II PMMA sheet/rod thresholds in this dataset were primarily measured in Opposed or Stagnation flow, whereas Concurrent flow is generally more hazardous.'
    );
  }

  if (isDropletMaterial && query.velocityCmS > 0) {
    domainViolations.push(
      isFr
        ? `Les essais gouttes FLEX (MG-011..MG-020) et seuils (MG-027..MG-030) ont été réalisés en 0g stagnant (U = 0 cm/s) ; un flux forcé de ${query.velocityCmS} cm/s sort du domaine FLEX.`
        : `FLEX droplet trials (MG-011..MG-020) and thresholds (MG-027..MG-030) were measured in stagnant 0g (U = 0 cm/s); forced airflow of ${query.velocityCmS} cm/s is outside FLEX test data.`
    );
  }

  if (query.velocityCmS >= 35) {
    epistemicCaveats.push(
      isFr
        ? `Ventilation élevée (${query.velocityCmS} cm/s) : BASS-II MG-006 montre une extinction par soufflage (blowoff) sur SIBAL à 47 cm/s (17,2 % O₂), prouvant qu’un seuil Umin unique est insuffisant.`
        : `High airflow (${query.velocityCmS} cm/s): BASS-II MG-006 demonstrated blowoff extinction on SIBAL at 47 cm/s (17.2% O₂), showing that a single U_min parameter cannot capture upper blowoff limits.`
    );
  }

  // Estimated Vf range from real experimental rows of matching material or solid analogs
  const matchingSolidTrials = records.filter(
    (r) =>
      r.rowType === 'Essai solide' &&
      r.vfMmS !== null &&
      r.vfMmS > 0 &&
      (isKnownMaterial ? r.loiKey === query.materialKey : r.materialFamily.includes('SIBAL'))
  );
  const estimatedVfRange =
    matchingSolidTrials.length > 0
      ? {
          min: Math.min(...matchingSolidTrials.map((r) => r.vfMmS!)),
          max: Math.max(...matchingSolidTrials.map((r) => r.vfMmS!)),
          basisIds: matchingSolidTrials.map((r) => r.id),
        }
      : null;

  // Honest Verdict Determination
  const inPressureDomain = Math.abs(query.pressureAtm - refPressure) <= 0.1;
  const inGravityDomain = query.gravity === '0g';
  const inZeroGRefDomain = inPressureDomain && inGravityDomain;

  let verdictLevel: HonestVerdictLevel;
  if (!isKnownMaterial) {
    verdictLevel = 'OUT_OF_DOMAIN_UNKNOWN';
  } else if (isDropletMaterial) {
    if (loiO2Threshold !== null && query.o2Percent < loiO2Threshold) {
      verdictLevel = inZeroGRefDomain ? 'NO_PROPAGATION_OBSERVED' : 'OUT_OF_DOMAIN_UNKNOWN';
      epistemicCaveats.push(
        isFr
          ? 'Les seuils gouttes liquides (FLEX) dépendent fortement du diamètre initial d₀, du gaz diluant (N₂/CO₂/He) et de l’allumage (MG-027..MG-030).'
          : 'Liquid droplet thresholds (FLEX) depend strongly on initial droplet diameter d₀, diluent gas (N₂/CO₂/He), and ignition energy (MG-027..MG-030).'
      );
    } else {
      verdictLevel = 'COOL_FLAME_INSTABILITY';
      epistemicCaveats.push(
        isFr
          ? 'Les essais FLEX ISS (MG-011..MG-019) révèlent une combustion en deux phases : après extinction chaude, une flamme froide quasi invisible persiste (hors Méthanol MG-020 / micro-explosion MG-014).'
          : 'FLEX ISS experiments (MG-011..MG-019) revealed two-stage combustion where hot flame extinction is followed by invisible low-temperature cool flame burning (except Methanol MG-020 / high-O₂ micro-explosion MG-014).'
      );
    }
  } else if (loiO2Threshold !== null && query.o2Percent < loiO2Threshold) {
    verdictLevel = inZeroGRefDomain ? 'NO_PROPAGATION_OBSERVED' : 'OUT_OF_DOMAIN_UNKNOWN';
    epistemicCaveats.push(
      isFr
        ? `O₂ (${query.o2Percent}%) est sous le seuil indicatif 0g/1 atm (${loiO2Threshold}%), mais selon MG-034/MG-036/MG-038 cela ne certifie pas l’ininflammabilité pour d’autres épaisseurs, pressions (${query.pressureAtm} atm) ou gravités (${query.gravity}).`
        : `O₂ (${query.o2Percent}%) is below the indicative 0g / ${refPressure} atm threshold (${loiO2Threshold}%), but per MG-034/MG-036/MG-038 this does NOT certify non-flammability across other thicknesses, pressures (${query.pressureAtm} atm), or gravity (${query.gravity}).`
    );
  } else if (uMinThreshold !== null && query.velocityCmS < uMinThreshold) {
    verdictLevel = 'QUENCH_NOT_GUARANTEED';
    epistemicCaveats.push(
      isFr
        ? `Flux (${query.velocityCmS} cm/s) sous Umin indicatif (${uMinThreshold} cm/s) : extinction radiative possible en 0g pur, mais (MG-035) un redémarrage ventilateur ou une convection lunaire/martienne peut relancer la flamme.`
        : `Airflow (${query.velocityCmS} cm/s) is below indicative U_min (${uMinThreshold} cm/s), suggesting possible radiative quenching in strict 0g. However (MG-035), any fan surge, crew movement, or convective flow in Lunar/Martian gravity can immediately re-establish active flame spread.`
    );
  } else {
    verdictLevel = 'CRITICAL_PROPAGATION';
  }

  // Confidence level
  let confidenceLabel: HonestAssessment['confidenceLabel'] = 'High (Near-Analog NASA Trial)';
  if (!isKnownMaterial || domainViolations.length >= 2) {
    confidenceLabel = 'Low (Extrapolated / Unknown)';
  } else if (domainViolations.length === 1 || !closestExperimentalTrial || closestExperimentalTrial.similarityScore < 75) {
    confidenceLabel = 'Moderate (Partial Analog)';
  }

  const legacyComparison = computeLegacyModel(records, query, language);

  return {
    verdictLevel,
    confidenceLabel,
    pO2Atm,
    isKnownMaterial,
    isDropletMaterial,
    matchedLoiRecord,
    loiO2Threshold,
    uMinThreshold,
    deltaO2Pts,
    estimatedVfRange,
    domainViolations,
    epistemicCaveats,
    rankedEvidence,
    closestExperimentalTrial,
    legacyComparison,
  };
}

export function buildDeterministicSynthesis(
  assessment: HonestAssessment,
  query: HabitatQuery,
  lang: Language,
  notice?: string
): SISynthesis {
  const topTrials = assessment.rankedEvidence
    .filter((e) => e.record.rowType === 'Essai solide' || e.record.rowType === 'Essai goutte')
    .slice(0, 3);
  const topLoi = assessment.rankedEvidence
    .filter((e) => e.record.rowType === 'Référence LOI')
    .slice(0, 2);

  const citedRecordIds = Array.from(
    new Set([
      ...topTrials.map((t) => t.record.id),
      ...topLoi.map((t) => t.record.id),
      ...(assessment.matchedLoiRecord ? [assessment.matchedLoiRecord.id] : []),
    ])
  );

  const isFr = lang === 'fr';
  const matLabel = query.materialKey === UNKNOWN_MATERIAL_KEY
    ? query.customMaterialName || (isFr ? 'Tissu X (non caractérisé)' : 'Fabric X (uncharacterized)')
    : translateMaterialLabel(query.materialKey, lang);
  const flowWord = translateFlowLabel(query.flowDirection, lang).toLowerCase();

  let directAnswer = '';
  let honestRiskSummary = '';

  if (assessment.verdictLevel === 'OUT_OF_DOMAIN_UNKNOWN') {
    if (!assessment.isKnownMaterial) {
      directAnswer = isFr
        ? `Réponse honnête : Il est scientifiquement impossible de certifier ou de chiffrer exactement le risque incendie pour « ${matLabel} » à ${query.o2Percent}% O₂ (${query.pressureAtm} atm, pO₂ = ${assessment.pO2Atm} atm) et ${query.velocityCmS} cm/s (${query.flowDirection}), car ce matériau ne figure dans aucun des 39 enregistrements NASA (Saffire, BASS-II, FLEX).`
        : `Honest Answer: We cannot certify or assign an exact flame spread rate for "${matLabel}" at ${query.o2Percent}% O₂ (${query.pressureAtm} atm, pO₂ = ${assessment.pO2Atm} atm) and ${query.velocityCmS} cm/s (${flowWord} flow) because this material is absent from all 39 NASA records (Saffire, BASS-II, FLEX).`;

      honestRiskSummary = isFr
        ? `Par comparaison conservative aux textiles testés dans la base : à ${query.o2Percent}% O₂ et ${query.velocityCmS} cm/s, un tissu cellulosique de type SIBAL (seuil indicatif 16.4% O₂, Umin 2.5 cm/s — MG-021) ou coton pur (16% — MG-032) serait en propagation active. Même le Nomex III (seuil indicatif 22.2% dans l’air standard — MG-010/MG-025) n’est pas validé au-delà de 22.2% O₂ ni en gravité ${query.gravity === 'lunar' ? 'lunaire (1/6g)' : query.gravity}.`
        : `Using tested NASA textiles as non-binding bounds: at ${query.o2Percent}% O₂ and ${query.velocityCmS} cm/s, cellulosic fabrics like SIBAL (indicative LOI 16.4%, Umin 2.5 cm/s — MG-021) or pure cotton (16% — MG-032) undergo active propagation. Even Nomex III (observed non-flammable at 22.2% in 1 atm microgravity — MG-010/MG-025) has no data supporting safety above 22.2% O₂ or in ${query.gravity} gravity.`;
    } else {
      const refP = query.materialKey === 'n-Décane (Goutte)' ? 0.5 : 1.0;
      const pGap = Math.abs(query.pressureAtm - refP) > 0.1;
      const gGap = query.gravity !== '0g';
      const gName =
        query.gravity === 'lunar'
          ? isFr
            ? 'gravité lunaire (1/6g)'
            : 'lunar gravity (1/6g)'
          : query.gravity === 'mars'
            ? isFr
              ? 'gravité martienne (0.38g)'
              : 'Martian gravity (0.38g)'
            : '0g';
      const factorsFr = [
        ...(pGap ? [`la pression (${query.pressureAtm} vs ${refP} atm)`] : []),
        ...(gGap ? [`la ${gName}`] : []),
      ].join(' et ');
      const factorsEn = [
        ...(pGap ? [`habitat pressure (${query.pressureAtm} vs ${refP} atm)`] : []),
        ...(gGap ? [gName] : []),
      ].join(' and ');

      directAnswer = isFr
        ? `Hors domaine de validation : bien que ${query.o2Percent}% O₂ soit sous le seuil indicatif 0g (${assessment.loiO2Threshold}%) de ${matLabel}, ${factorsFr} sort des essais NASA en 0g.`
        : `Out of validation domain: although ${query.o2Percent}% O₂ sits below the 0g indicative threshold (${assessment.loiO2Threshold}%) for ${matLabel}, ${factorsEn} extrapolates beyond NASA 0g flight tests.`;

      honestRiskSummary = isFr
        ? `L’O₂ seul ne suffit pas à garantir une zone sûre : la gravité partielle (convection) et la pression totale modifient le transfert thermique et l’extinction (MG-034, MG-038).`
        : `Low O₂ alone does not guarantee a safe zone: partial gravity buoyancy and non-reference total pressure shift flammability limits and heat transfer (MG-034, MG-038).`;
    }
  } else if (assessment.verdictLevel === 'CRITICAL_PROPAGATION') {
    directAnswer = isFr
      ? `Risque critique de propagation active pour ${matLabel} à ${query.o2Percent}% O₂ (${query.pressureAtm} atm, pO₂ = ${assessment.pO2Atm} atm) et flux ${flowWord} de ${query.velocityCmS} cm/s.`
      : `Critical active flame propagation risk for ${matLabel} at ${query.o2Percent}% O₂ (${query.pressureAtm} atm, pO₂ = ${assessment.pO2Atm} atm) and ${flowWord} flow of ${query.velocityCmS} cm/s.`;

    honestRiskSummary = isFr
      ? `La concentration O₂ dépasse le seuil indicatif (${assessment.loiO2Threshold}% O₂, écart +${assessment.deltaO2Pts} pts) et le flux d’air (${query.velocityCmS} cm/s) dépasse Umin (${assessment.uMinThreshold} cm/s).`
      : `Oxygen exceeds the indicative threshold (${assessment.loiO2Threshold}% O₂, +${assessment.deltaO2Pts} pts margin) and airflow (${query.velocityCmS} cm/s) exceeds indicative Umin (${assessment.uMinThreshold} cm/s).`;
  } else if (assessment.verdictLevel === 'QUENCH_NOT_GUARANTEED') {
    directAnswer = isFr
      ? `Extinction radiative possible en 0g pur, mais sûreté NON garantie pour ${matLabel} à ${query.o2Percent}% O₂ et ${query.velocityCmS} cm/s.`
      : `Radiative quenching possible in strict 0g, but safety is NOT guaranteed for ${matLabel} at ${query.o2Percent}% O₂ and ${query.velocityCmS} cm/s.`;

    honestRiskSummary = isFr
      ? `Bien que ${query.velocityCmS} cm/s soit sous Umin indicatif (${assessment.uMinThreshold} cm/s), O₂ (${query.o2Percent}%) reste au-dessus du seuil (${assessment.loiO2Threshold}%). Comme le souligne MG-035, toute reprise de ventilation ou convection (${query.gravity}) peut relancer une propagation rapide.`
      : `While ${query.velocityCmS} cm/s sits below indicative Umin (${assessment.uMinThreshold} cm/s), O₂ (${query.o2Percent}%) remains above threshold (${assessment.loiO2Threshold}%). As flagged in MG-035, any ventilation surge or buoyancy (${query.gravity}) can re-ignite active spread.`;
  } else if (assessment.verdictLevel === 'COOL_FLAME_INSTABILITY') {
    directAnswer = isFr
      ? `Régime instable / flamme froide possible pour ${matLabel} à ${query.o2Percent}% O₂ (${query.pressureAtm} atm).`
      : `Unstable / cool-flame combustion regime possible for ${matLabel} at ${query.o2Percent}% O₂ (${query.pressureAtm} atm).`;

    honestRiskSummary = isFr
      ? `Les essais FLEX (ISS) montrent qu’après extinction de la flamme chaude, les alcanes liquides peuvent entretenir une flamme froide quasi invisible à basse température (MG-011..MG-019) ou subir une micro-explosion à O₂ élevé (MG-014).`
      : `FLEX ISS trials show liquid alkanes can transition after hot-flame extinction into nearly invisible cool-flame burning (MG-011..MG-019) or micro-explosion at elevated O₂ (MG-014).`;
  } else {
    directAnswer = isFr
      ? `Sous le seuil indicatif NASA (${query.o2Percent}% < ${assessment.loiO2Threshold}% O₂), mais sans certification universelle d’ininflammabilité.`
      : `Below indicative NASA threshold (${query.o2Percent}% < ${assessment.loiO2Threshold}% O₂), though NOT universally certified non-flammable.`;

    honestRiskSummary = isFr
      ? `Dans les bornes ponctuelles de la matrice LOI (MG-021..MG-032), aucune propagation soutenue n’est attendue à 1 atm / 0g, mais les alertes MG-036 et MG-038 rappellent qu’un seuil tabulé ne couvre ni les épaisseurs différentes ni la gravité partielle.`
      : `Within the narrow reference bounds of the LOI matrix (MG-021..MG-032), sustained spread was not observed at 1 atm / 0g, yet MG-036 & MG-038 warn that tabulated thresholds do not certify safety across varying thickness, pressure, or partial gravity.`;
  }

  const evidenceBreakdown = topTrials.map((item) => {
    const r = item.record;
    const coolLabel = r.coolFlame.toLowerCase().startsWith('oui')
      ? (isFr ? 'Oui' : 'Yes')
      : r.coolFlame.toLowerCase().startsWith('non')
        ? (isFr ? 'Non' : 'No')
        : r.coolFlame || 'n/a';
    const measure =
      r.vfMmS !== null
        ? `Vf = ${r.vfMmS} mm/s`
        : r.kHotMm2S !== null
          ? `K_hot = ${r.kHotMm2S} mm²/s, ${isFr ? 'flamme froide' : 'cool flame'}: ${coolLabel}`
          : translateCsvField(r.initialObservation, lang) || 'See NASA record provenance';
    const matName = translateMaterialLabel(r.materialOriginal, lang);
    const dirName = r.flowDirection ? translateFlowLabel(r.flowDirection, lang) : '—';
    return `${r.id} (${r.mission} · ${r.sourceId}): ${matName}, O₂=${r.o2Percent ?? '—'}%, P=${r.pressureAtm ?? '—'} atm, U=${r.velocityCmS ?? '—'} cm/s (${dirName}) → ${measure}. [${item.similarityScore}% match]`;
  });

  const whatWeDoNotKnow = [
    ...assessment.domainViolations,
    ...assessment.epistemicCaveats,
    ...(assessment.legacyComparison.divergenceWarnings.length > 0
      ? [assessment.legacyComparison.divergenceWarnings[0]]
      : []),
  ];

  const safetyRecommendations = isFr
    ? [
        !assessment.isKnownMaterial
          ? `Exiger un essai NASA-STD-6001 Test 1 (1g) et une caractérisation flux concurrent/opposé en pression d’habitat (${query.pressureAtm} atm) avant d’autoriser « ${matLabel} ».`
          : `Vérifier les conditions d’épaisseur réelle et de géométrie par rapport aux échantillons NASA de référence (${assessment.closestExperimentalTrial?.record.originalDimensions || 'voir fiche'}).`,
        query.gravity !== '0g'
          ? `Ne pas extrapoler directement les extinctions 0g vers la gravité ${query.gravity === 'lunar' ? 'lunaire (1/6g)' : 'martienne (0.38g)'} ; appliquer une marge de sécurité sur O₂ et contrôler les courants de convection.`
          : 'Maintenir un contrôle strict des débits de ventilation locaux : éviter la plage critique de propagation concurrente (5–30 cm/s) et surveiller les redémarrages de ventilateurs.',
        query.pressureAtm < 0.8 && query.o2Percent >= 26
          ? `En atmosphère d’exploration hypobare enrichie (${query.o2Percent}% O₂, ${query.pressureAtm} atm), utiliser des matériaux de classe Nomex/ignifugés validés à la pO₂ et pression totale cibles.`
          : 'Utiliser des capteurs multi-spectres (détection UV/IR + CO) si des hydrocarbures liquides (risque de flamme froide invisible) sont présents.',
      ]
    : [
        !assessment.isKnownMaterial
          ? `Require NASA-STD-6001 Test 1 screening plus concurrent/opposed flow testing at target habitat pressure (${query.pressureAtm} atm) before qualifying "${matLabel}".`
          : `Verify exact material thickness and mounting geometry against the closest NASA sample (${assessment.closestExperimentalTrial?.record.originalDimensions || 'see record'}).`,
        query.gravity !== '0g'
          ? `Do not extrapolate 0g radiative extinction directly to ${query.gravity} gravity; apply conservative O₂ margins and account for buoyancy-assisted convection.`
          : 'Control local HVAC airflow carefully: avoid unmonitored concurrent flow in the 5–30 cm/s regime and account for fan startup transients.',
        query.pressureAtm < 0.8 && query.o2Percent >= 26
          ? `For hypobaric oxygen-enriched exploration atmospheres (${query.o2Percent}% O₂, ${query.pressureAtm} atm), qualify flame-resistant textiles specifically at reduced total pressure.`
          : 'Deploy multi-band flame/gas sensing (UV/IR + CO) wherever liquid fuels are handled due to invisible cool-flame hazards.',
      ];

  return {
    directAnswer,
    honestRiskSummary,
    evidenceBreakdown,
    whatWeDoNotKnow,
    safetyRecommendations,
    citedRecordIds,
    mode: 'deterministic',
    modelName: 'NASA-PSI Deterministic Audit Engine',
    generatedAt: new Date().toISOString(),
    notice,
  };
}

export interface DomainCheckItem {
  key: 'material' | 'pressure' | 'gravity' | 'flow';
  label: string;
  ok: boolean;
  detail: string;
}

export function computeDomainChecks(
  assessment: HonestAssessment,
  query: HabitatQuery,
  language: Language = 'en'
): { validCount: number; total: number; checks: DomainCheckItem[] } {
  const isFr = language === 'fr';
  const refPressure = query.materialKey === 'n-Décane (Goutte)' ? 0.5 : 1.0;
  const pressureOk = Math.abs(query.pressureAtm - refPressure) <= 0.1;
  const gravityOk = query.gravity === '0g';
  const flowOk =
    !(
      query.flowDirection === 'Concurrent' &&
      query.materialKey.includes('PMMA') &&
      !query.materialKey.includes('Cast')
    ) && !(assessment.isDropletMaterial && query.velocityCmS > 0);

  const checks: DomainCheckItem[] = [
    {
      key: 'material',
      label: isFr ? 'Matériau NASA' : 'NASA Material',
      ok: assessment.isKnownMaterial,
      detail: assessment.isKnownMaterial
        ? translateMaterialLabel(query.materialKey, language)
        : isFr
          ? `${query.customMaterialName || 'Inconnu'} absent`
          : `${query.customMaterialName || 'Unknown'} unlisted`,
    },
    {
      key: 'pressure',
      label: isFr ? 'Pression réf.' : 'Ref. Pressure',
      ok: pressureOk,
      detail: `${query.pressureAtm.toFixed(2)} vs ${refPressure.toFixed(1)} atm`,
    },
    {
      key: 'gravity',
      label: isFr ? 'Gravité 0g' : '0g Domain',
      ok: gravityOk,
      detail:
        query.gravity === '0g'
          ? isFr
            ? '0g Microgravité'
            : '0g Microgravity'
          : query.gravity === 'lunar'
            ? isFr
              ? '1/6g Lune ≠ 0g'
              : '1/6g Lunar ≠ 0g'
            : '0.38g Mars ≠ 0g',
    },
    {
      key: 'flow',
      label: isFr ? 'Flux testé' : 'Tested Flow',
      ok: flowOk,
      detail: `${translateFlowLabel(query.flowDirection, language)} · ${query.velocityCmS} cm/s`,
    },
  ];

  const validCount = checks.filter((c) => c.ok).length;
  return { validCount, total: checks.length, checks };
}

const EN_MATERIAL_MAP: Record<string, string> = {
  'Tissu SIBAL (75% Coton/25% Verre)': 'SIBAL Fabric (75% Cotton/25% Glass)',
  'Tissu SIBAL (Coton/Verre)': 'SIBAL Fabric (Cotton/Glass)',
  'Tissu SIBAL': 'SIBAL Fabric',
  'Plaque PMMA Épaisse (Cast)': 'Thick Cast PMMA Plate',
  'PMMA (Cast PMMA)': 'Cast PMMA Plate',
  'Plaque PMMA': 'PMMA Slab',
  'Film PMMA': 'PMMA Film',
  'Tige PMMA Noire': 'Black PMMA Rod',
  'Nomex III Naturel': 'Natural Nomex III',
  'Tissu Nomex III': 'Nomex III Fabric',
  'Tissu Coton Pur': 'Pure Cotton Fabric',
  'Silicone (0.25 - 0.61 mm)': 'Silicone Sheet (0.25–0.61 mm)',
  'n-Décane': 'n-Decane',
  'n-Décane (Goutte)': 'n-Decane (Droplet)',
  'n-Heptane': 'n-Heptane',
  'n-Heptane (Goutte)': 'n-Heptane (Droplet)',
  'n-Octane': 'n-Octane',
  'n-Octane (Goutte)': 'n-Octane (Droplet)',
  'Méthanol': 'Methanol',
  'Méthanol (Goutte)': 'Methanol (Droplet)',
  'Plaque fine PMMA (0.1-0.4 mm)': 'Thin PMMA Film (0.1–0.4 mm)',
  'Plaque PMMA Épaisse (1-5 mm)': 'Thick PMMA Slab (1–5 mm)',
  'Tige PMMA (6.35 mm - 12.7 mm)': 'PMMA Rod (6.35–12.7 mm)',
};

const EN_ROW_TYPE_MAP: Record<string, string> = {
  'Essai solide': 'Solid Trial',
  'Essai goutte': 'Droplet Trial',
  'Référence LOI': 'LOI Threshold',
  'Scénario habitat': 'Habitat Scenario',
  'Calculateur initial': 'Legacy Calculator',
};

export function translateMaterialLabel(raw: string, language: Language): string {
  if (language === 'fr') return raw;
  return EN_MATERIAL_MAP[raw] ?? raw;
}

export function translateFlowLabel(raw: string, language: Language): string {
  if (language === 'fr') return raw;
  if (raw === 'Opposé') return 'Opposed';
  return raw;
}

export function translateRowTypeLabel(raw: string, language: Language): string {
  if (language === 'fr') return raw;
  return EN_ROW_TYPE_MAP[raw] ?? raw;
}

export function buildQuestionSummary(query: HabitatQuery, language: Language): string {
  const mat =
    query.materialKey === UNKNOWN_MATERIAL_KEY
      ? query.customMaterialName || (language === 'fr' ? 'Tissu X' : 'Fabric X')
      : translateMaterialLabel(query.materialKey, language);
  const flow = translateFlowLabel(query.flowDirection, language).toLowerCase();
  if (language === 'fr') {
    const hab =
      query.gravity === 'lunar'
        ? 'habitat lunaire (1/6g)'
        : query.gravity === 'mars'
          ? 'habitat martien (0.38g)'
          : 'habitat en microgravité (0g)';
    return `Mon ${hab} utilise ${mat}, O₂ ${query.o2Percent.toFixed(1)}%, pression ${query.pressureAtm.toFixed(2)} atm, flux ${flow} ${query.velocityCmS.toFixed(1)} cm/s. Quel est le risque incendie ?`;
  }
  const hab =
    query.gravity === 'lunar'
      ? 'lunar habitat (1/6g)'
      : query.gravity === 'mars'
        ? 'Martian habitat (0.38g)'
        : 'microgravity habitat (0g)';
  return `My ${hab} uses ${mat}, ${query.o2Percent.toFixed(1)}% O₂, ${query.pressureAtm.toFixed(2)} atm pressure, ${query.velocityCmS.toFixed(1)} cm/s ${flow} airflow. What is the fire risk?`;
}


