import type { CopyDictionary } from '../i18n/translations';
import { translateCsvField, translateSourceId } from '../lib/csvTranslations';
import { translateMaterialLabel, translateRowTypeLabel } from '../lib/fireSafetyEngine';
import type { Language, MicrogravityRecord } from '../types/fireSafety';

interface LegacyModelAuditProps {
  copy: CopyDictionary;
  language: Language;
  records: MicrogravityRecord[];
  onSelectRecord: (record: MicrogravityRecord) => void;
}

export function LegacyModelAudit({
  copy,
  language,
  records,
  onSelectRecord,
}: LegacyModelAuditProps) {
  const saffireTrials = records.filter((r) =>
    ['MG-001', 'MG-002', 'MG-003'].includes(r.id)
  );
  const legacyRows = records.filter(
    (r) => r.rowType === 'Scénario habitat' || r.rowType === 'Calculateur initial'
  );

  // Quantitative comparison: MG-039 predicts Vf = 3.25 mm/s at U=20, O2=21%
  const comparisonBars = [
    {
      id: 'MG-039',
      label: 'MG-039 Legacy Formula (U=20, 21% O₂)',
      vf: 3.25,
      note: 'Ad hoc formula 0.1*(U - 2.5) + 1.5 — uncalibrated',
      isLegacy: true,
    },
    ...saffireTrials.map((r) => ({
      id: r.id,
      label: `${r.id} ${r.sourceId} (U=${r.velocityCmS}, ${r.o2Percent}% O₂)`,
      vf: r.vfMmS ?? 0,
      note:
        language === 'fr'
          ? r.initialObservation
          : `${r.mission} flight measurement · ${translateMaterialLabel(r.materialOriginal, language)}`,
      isLegacy: false,
    })),
  ];

  return (
    <section
      id="model-audit"
      aria-label={copy.auditSectionHeading}
      className="rounded-lg border border-slate-200 bg-white p-6 space-y-6"
    >
      <div>
        <h2 className="text-lg font-semibold text-slate-900">
          {copy.auditSectionHeading}
        </h2>
        <p className="mt-1 text-sm text-slate-600">{copy.auditSectionSubtitle}</p>
      </div>

      {/* Quantitative Spread Rate Divergence Chart */}
      <div className="rounded-md border border-slate-200 bg-slate-50/70 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-semibold text-slate-900">
            SIBAL Flame Spread Rate: Legacy Equation (MG-039) vs. Saffire Flight Measurements
          </h3>
          <span className="font-mono text-xs text-slate-500">Unit: mm/s</span>
        </div>

        <div className="space-y-3">
          {comparisonBars.map((bar) => {
            const widthPct = Math.min(100, (bar.vf / 3.6) * 100);
            const rec = records.find((r) => r.id === bar.id);
            return (
              <div key={bar.id} className="space-y-1">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => rec && onSelectRecord(rec)}
                    className="font-medium text-slate-900 hover:text-blue-700 hover:underline text-left"
                  >
                    {bar.label}
                  </button>
                  <span className="font-mono font-semibold tabular-nums text-slate-900">
                    {bar.vf.toFixed(2)} mm/s
                  </span>
                </div>
                <div className="h-3 w-full rounded bg-slate-200 overflow-hidden">
                  <div
                    className={`h-full rounded ${
                      bar.isLegacy ? 'bg-amber-600' : 'bg-blue-600'
                    }`}
                    style={{ width: `${widthPct}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-500">{bar.note}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Legacy Scenarios Audit Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {legacyRows.map((row) => (
          <div
            key={row.id}
            className="flex flex-col justify-between rounded-md border border-slate-200 bg-white p-4 space-y-3"
          >
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                <span className="font-mono font-semibold text-slate-900">
                  {row.id}
                </span>
                <span>{translateRowTypeLabel(row.rowType, language)}</span>
              </div>
              <h3 className="text-sm font-semibold text-slate-900">
                {translateSourceId(row.sourceId, language)}
              </h3>
              <div className="font-mono text-xs tabular-nums text-slate-600">
                {translateMaterialLabel(row.materialOriginal, language)} · O₂ {row.o2Percent}% · P {row.pressureAtm} atm · U{' '}
                {row.velocityCmS} cm/s
              </div>
              <p className="pt-1 text-xs leading-relaxed text-slate-700">
                {translateCsvField(row.scientificAlert, language)}
              </p>
            </div>

            <div className="flex items-center justify-between border-t border-slate-100 pt-3">
              <span className="text-[11px] font-medium text-slate-500 truncate max-w-[200px]">
                {translateCsvField(row.validityDomain, language)}
              </span>
              <button
                type="button"
                onClick={() => onSelectRecord(row)}
                className="whitespace-nowrap shrink-0 text-xs font-medium text-blue-700 hover:underline"
              >
                {copy.inspectRecord}
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
