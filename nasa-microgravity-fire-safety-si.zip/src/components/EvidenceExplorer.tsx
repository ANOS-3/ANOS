import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import type { CopyDictionary } from '../i18n/translations';
import { translateCsvField, translateSourceId } from '../lib/csvTranslations';
import {
  translateFlowLabel,
  translateMaterialLabel,
  translateRowTypeLabel,
} from '../lib/fireSafetyEngine';
import type { Language, MicrogravityRecord, RankedEvidence, RowType } from '../types/fireSafety';

interface EvidenceExplorerProps {
  copy: CopyDictionary;
  language: Language;
  rankedEvidence: RankedEvidence[];
  onSelectRecord: (record: MicrogravityRecord) => void;
}

type TypeFilter = 'ALL' | RowType;

export function EvidenceExplorer({
  copy,
  language,
  rankedEvidence,
  onSelectRecord,
}: EvidenceExplorerProps) {
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'similarity' | 'id' | 'o2'>('similarity');

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = rankedEvidence.filter(({ record }) => {
      if (typeFilter !== 'ALL' && record.rowType !== typeFilter) return false;
      if (!q) return true;
      return (
        record.id.toLowerCase().includes(q) ||
        record.mission.toLowerCase().includes(q) ||
        record.materialOriginal.toLowerCase().includes(q) ||
        record.scientificAlert.toLowerCase().includes(q) ||
        record.initialObservation.toLowerCase().includes(q)
      );
    });

    if (sortBy === 'id') {
      return [...list].sort((a, b) => a.record.id.localeCompare(b.record.id));
    }
    if (sortBy === 'o2') {
      return [...list].sort((a, b) => {
        const ao2 = a.record.o2Percent ?? a.record.loiO2Threshold ?? 0;
        const bo2 = b.record.o2Percent ?? b.record.loiO2Threshold ?? 0;
        return bo2 - ao2;
      });
    }
    return list;
  }, [rankedEvidence, typeFilter, searchQuery, sortBy]);

  const isFr = language === 'fr';
  const filterButtons: { key: TypeFilter; label: string }[] = [
    { key: 'ALL', label: isFr ? `Tout (${rankedEvidence.length})` : `All (${rankedEvidence.length})` },
    { key: 'Essai solide', label: isFr ? 'Essais Solides (10)' : 'Solid Trials (10)' },
    { key: 'Essai goutte', label: isFr ? 'Gouttes FLEX (10)' : 'FLEX Droplets (10)' },
    { key: 'Référence LOI', label: isFr ? 'Matrice LOI (12)' : 'LOI Matrix (12)' },
    { key: 'Scénario habitat', label: isFr ? 'Scénarios (6)' : 'Scenarios (6)' },
    { key: 'Calculateur initial', label: isFr ? 'Calculateur (1)' : 'Calculator (1)' },
  ];

  return (
    <section
      id="evidence"
      aria-label={copy.evidenceHeading}
      className="rounded-lg border border-slate-200 bg-white p-6 space-y-5"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            {copy.evidenceHeading}
          </h2>
          <p className="mt-1 text-sm text-slate-600">{copy.evidenceSubtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={copy.searchPlaceholder}
              aria-label={copy.searchPlaceholder}
              className="w-64 rounded-md border border-slate-300 bg-slate-50 py-1.5 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-600">
            <span>Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'similarity' | 'id' | 'o2')}
              className="rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-800 focus:border-blue-600 focus:outline-none"
            >
              <option value="similarity">Relevance Score</option>
              <option value="id">Record ID (MG-001..039)</option>
              <option value="o2">O₂ Concentration</option>
            </select>
          </label>
        </div>
      </div>

      {/* Type Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1 rounded-md border border-slate-200 bg-slate-100 p-1">
        {filterButtons.map((btn) => (
          <button
            key={btn.key}
            type="button"
            onClick={() => setTypeFilter(btn.key)}
            className={`whitespace-nowrap rounded px-3 py-1.5 text-xs font-medium transition-colors ${
              typeFilter === btn.key
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Data Table */}
      <div className="overflow-x-auto border border-slate-200 rounded-md">
        <table className="w-full divide-y divide-slate-200 text-left text-xs">
          <thead className="bg-slate-50 text-slate-500">
            <tr>
              <th className="px-2.5 py-2 font-semibold">ID</th>
              <th className="px-2 py-2 font-semibold">Match</th>
              <th className="px-2.5 py-2 font-semibold">Mission / Type</th>
              <th className="px-2.5 py-2 font-semibold">Material / Fuel</th>
              <th className="px-2.5 py-2 font-semibold text-right">O₂ / LOI</th>
              <th className="px-2.5 py-2 font-semibold text-right">P (atm)</th>
              <th className="px-2.5 py-2 font-semibold text-right">U (cm/s)</th>
              <th className="px-2.5 py-2 font-semibold text-right">Vf / K / Result</th>
              <th className="px-2.5 py-2 font-semibold">Verification & Alert</th>
              <th className="px-2.5 py-2 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center text-sm text-slate-500">
                  No NASA records match your current filter. Try clearing the search query or switching tabs.
                </td>
              </tr>
            ) : (
              filtered.map(({ record, similarityScore }) => {
                const o2Display =
                  record.o2Percent !== null
                    ? `${record.o2Percent}%`
                    : record.loiO2Threshold !== null
                      ? `LOI ${record.loiO2Threshold}%`
                      : '—';
                const uDisplay =
                  record.velocityCmS !== null
                    ? `${record.velocityCmS}`
                    : record.uMinCmS !== null
                      ? `≥ ${record.uMinCmS}`
                      : '—';
                const resultDisplay =
                  record.vfMmS !== null
                    ? `Vf ${record.vfMmS} mm/s`
                    : record.kHotMm2S !== null
                      ? `K ${record.kHotMm2S} mm²/s`
                      : translateCsvField(record.legacyModelResult || record.initialObservation, language) || '—';

                return (
                  <tr
                    key={record.id}
                    className="hover:bg-slate-50/90 transition-colors"
                  >
                    <td className="px-2.5 py-2 font-mono font-semibold tabular-nums text-slate-900 whitespace-nowrap">
                      {record.id}
                    </td>
                    <td className="px-2.5 py-2 font-mono tabular-nums whitespace-nowrap">
                      <span
                        className={
                          similarityScore >= 75
                            ? 'font-semibold text-blue-700'
                            : similarityScore >= 50
                              ? 'text-slate-700'
                              : 'text-slate-400'
                        }
                      >
                        {similarityScore}%
                      </span>
                    </td>
                    <td className="px-2.5 py-2 whitespace-nowrap">
                      <div className="font-medium text-slate-900">
                        {record.mission === 'SIMULATION (ancienne)' && language === 'en'
                          ? 'LEGACY SIMULATION'
                          : record.mission}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {translateRowTypeLabel(record.rowType, language)} · {translateSourceId(record.sourceId, language)}
                      </div>
                    </td>
                    <td className="px-2.5 py-2 max-w-[175px]">
                      <div className="font-medium text-slate-900 truncate">
                        {translateMaterialLabel(record.materialOriginal, language)}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {translateFlowLabel(record.flowDirection, language) ||
                          translateCsvField(record.geometry, language) ||
                          record.atmosphereDiluent}
                      </div>
                    </td>
                    <td className="px-2.5 py-2 font-mono tabular-nums text-right text-slate-800 whitespace-nowrap">
                      {o2Display}
                    </td>
                    <td className="px-2.5 py-2 font-mono tabular-nums text-right text-slate-700 whitespace-nowrap">
                      {record.pressureAtm !== null ? record.pressureAtm.toFixed(2) : '—'}
                    </td>
                    <td className="px-2.5 py-2 font-mono tabular-nums text-right text-slate-700 whitespace-nowrap">
                      {uDisplay}
                    </td>
                    <td className="px-2.5 py-2 font-mono tabular-nums text-right text-slate-900 max-w-[140px] truncate">
                      {resultDisplay}
                    </td>
                    <td className="px-2.5 py-2 max-w-[190px]">
                      <div className="text-slate-800 truncate">
                        {translateCsvField(record.verificationStatus, language)}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {translateCsvField(record.scientificAlert, language)}
                      </div>
                    </td>
                    <td className="px-2.5 py-2 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onSelectRecord(record)}
                        className="rounded border border-slate-300 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:border-blue-600 hover:text-blue-700 transition-colors"
                      >
                        {language === 'fr' ? 'Détails' : 'Inspect'}
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
