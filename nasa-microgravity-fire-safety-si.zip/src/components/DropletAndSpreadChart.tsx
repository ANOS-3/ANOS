import { useState } from 'react';
import { translateMaterialLabel } from '../lib/fireSafetyEngine';
import type { Language, MicrogravityRecord } from '../types/fireSafety';

interface DropletAndSpreadChartProps {
  records: MicrogravityRecord[];
  language: Language;
  onSelectRecord: (record: MicrogravityRecord) => void;
}

export function DropletAndSpreadChart({
  records,
  language,
  onSelectRecord,
}: DropletAndSpreadChartProps) {
  const [chartTab, setChartTab] = useState<'spread' | 'droplets'>('spread');
  const isFr = language === 'fr';

  const solidSpreadRows = records.filter((r) =>
    ['MG-001', 'MG-002', 'MG-003', 'MG-008', 'MG-007'].includes(r.id)
  );
  const dropletRows = records.filter(
    (r) => r.rowType === 'Essai goutte' && r.d0Mm !== null
  );

  const bars = [
    {
      id: 'MG-039',
      label: isFr ? 'MG-039 Formule Héritée' : 'MG-039 Legacy Formula',
      sub: '21% O₂ · 20 cm/s',
      vf: 3.25,
      isLegacy: true,
    },
    ...solidSpreadRows.map((r) => ({
      id: r.id,
      label: `${r.id} ${r.sourceId}`,
      sub: `${r.o2Percent}% O₂ · ${r.velocityCmS} cm/s`,
      vf: r.vfMmS ?? 0,
      isLegacy: false,
    })),
  ];

  const maxD = 4.3;

  return (
    <section
      aria-label="Flame spread and droplet combustion visuals"
      className="flex flex-col rounded-lg border border-slate-200 bg-white p-4"
    >
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-600">
            {chartTab === 'spread'
              ? isFr
                ? 'Vitesse de Flamme Vf (mm/s) : Modèle vs NASA'
                : 'Flame Spread Vf (mm/s): Legacy vs. NASA Flight'
              : isFr
                ? 'Cercles FLEX (10 essais) : d₀ → Ext. Chaude → Flamme Froide'
                : 'FLEX Droplet Circles (10 trials): d₀ → Hot Ext. → Cool Flame'}
          </h2>
        </div>

        <div className="flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 p-0.5">
          <button
            type="button"
            onClick={() => setChartTab('spread')}
            className={`whitespace-nowrap rounded px-2.5 py-1 text-[11px] font-medium transition-colors ${
              chartTab === 'spread'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isFr ? 'Graphe Vf (Solides)' : 'Spread Bars (Solids)'}
          </button>
          <button
            type="button"
            onClick={() => setChartTab('droplets')}
            className={`whitespace-nowrap rounded px-2.5 py-1 text-[11px] font-medium transition-colors ${
              chartTab === 'droplets'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isFr ? 'Cercles FLEX (10)' : 'Droplet Circles (10)'}
          </button>
        </div>
      </div>

      {chartTab === 'spread' ? (
        <div className="space-y-2">
          {bars.map((bar) => {
            const pct = Math.max(3, Math.min(100, (bar.vf / 3.5) * 100));
            const rec = records.find((r) => r.id === bar.id);
            const vfText = bar.vf < 0.1 && bar.vf > 0 ? bar.vf.toFixed(3) : bar.vf.toFixed(2);
            return (
              <div key={bar.id} className="grid grid-cols-12 items-center gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => rec && onSelectRecord(rec)}
                  className="col-span-5 truncate text-left font-medium text-slate-800 hover:text-blue-700 hover:underline"
                  title={`${bar.label} (${bar.sub})`}
                >
                  {bar.label}
                </button>
                <div className="col-span-5 h-2.5 rounded bg-slate-100 overflow-hidden border border-slate-200">
                  <div
                    className={`h-full ${bar.isLegacy ? 'bg-amber-600' : 'bg-blue-600'}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="col-span-2 text-right font-mono text-[11px] font-semibold tabular-nums text-slate-900">
                  {vfText}
                </span>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-2">
          <div className="grid grid-cols-5 gap-1.5">
            {dropletRows.map((rec) => {
              const d0 = rec.d0Mm ?? 3;
              const dHot = rec.extHotMm ?? 0;
              const dCold = rec.extColdMm ?? 0;
              const toR = (mm: number) => Math.max(0, (mm / maxD) * 20);
              return (
                <button
                  key={rec.id}
                  type="button"
                  onClick={() => onSelectRecord(rec)}
                  className="flex flex-col items-center rounded border border-slate-200 bg-slate-50/70 px-1.5 py-1.5 hover:border-blue-600 transition-colors"
                  title={`${rec.id} · ${translateMaterialLabel(rec.materialOriginal, language)} · d₀=${d0}mm · Ext.Hot=${dHot}mm · Ext.Cold=${dCold}mm`}
                >
                  <svg width={44} height={44} viewBox="0 0 44 44">
                    <circle
                      cx={22}
                      cy={22}
                      r={toR(d0)}
                      fill="#E2E8F0"
                    />
                    {dHot > 0 && (
                      <circle
                        cx={22}
                        cy={22}
                        r={toR(dHot)}
                        fill="rgba(220, 38, 38, 0.25)"
                        stroke="#DC2626"
                        strokeWidth={1.1}
                      />
                    )}
                    {dCold > 0 && (
                      <circle
                        cx={22}
                        cy={22}
                        r={toR(dCold)}
                        fill="rgba(217, 119, 6, 0.45)"
                        stroke="#D97706"
                        strokeWidth={1.1}
                      />
                    )}
                    <circle
                      cx={22}
                      cy={22}
                      r={toR(d0)}
                      fill="none"
                      stroke="#475569"
                      strokeWidth={1}
                      strokeDasharray="2 1.5"
                    />
                  </svg>
                  <span className="font-mono text-[10px] font-semibold text-slate-900">
                    {rec.id}
                  </span>
                  <span className="text-[9px] text-slate-500 truncate max-w-full">
                    {translateMaterialLabel(rec.materialOriginal, language)} {rec.o2Percent}%
                  </span>
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500 border-t border-slate-100 pt-1.5">
            <span>
              {isFr
                ? 'Pointillés : d₀ initial · Rouge : Ext. chaude · Ambre : Flamme froide'
                : 'Dashed: d₀ initial · Red: Hot Ext. · Amber: Cool Flame'}
            </span>
            <span className="font-mono">0–4.3 mm</span>
          </div>
        </div>
      )}
    </section>
  );
}
