import { ExternalLink, X } from 'lucide-react';
import type { CopyDictionary } from '../i18n/translations';
import { translateCsvField, translateSourceId } from '../lib/csvTranslations';
import {
  translateFlowLabel,
  translateMaterialLabel,
  translateRowTypeLabel,
} from '../lib/fireSafetyEngine';
import type { Language, MicrogravityRecord } from '../types/fireSafety';

interface RecordDetailDrawerProps {
  copy: CopyDictionary;
  language: Language;
  record: MicrogravityRecord | null;
  onClose: () => void;
}

export function RecordDetailDrawer({
  copy,
  language,
  record,
  onClose,
}: RecordDetailDrawerProps) {
  if (!record) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="record-dialog-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-lg border border-slate-200 bg-white p-6 space-y-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
              <span className="font-semibold text-blue-700">{record.id}</span>
              <span aria-hidden="true">·</span>
              <span>{translateRowTypeLabel(record.rowType, language)}</span>
              <span aria-hidden="true">·</span>
              <span>{record.mission}</span>
            </div>
            <h2
              id="record-dialog-title"
              className="mt-1 text-lg font-semibold text-slate-900"
            >
              {translateSourceId(record.sourceId, language)} — {translateMaterialLabel(record.materialOriginal, language)}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={copy.closeModal}
            className="rounded-md border border-slate-200 p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {/* Key Measurements Grid */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 font-mono text-xs tabular-nums">
          <div className="rounded border border-slate-200 bg-slate-50 p-2.5">
            <div className="text-slate-500">O₂ / LOI</div>
            <div className="mt-0.5 font-semibold text-slate-900">
              {record.o2Percent !== null
                ? `${record.o2Percent}%`
                : record.loiO2Threshold !== null
                  ? `LOI ${record.loiO2Threshold}%`
                  : '—'}
            </div>
          </div>
          <div className="rounded border border-slate-200 bg-slate-50 p-2.5">
            <div className="text-slate-500">Pressure / pO₂</div>
            <div className="mt-0.5 font-semibold text-slate-900">
              {record.pressureAtm !== null ? `${record.pressureAtm} atm` : '—'}{' '}
              {record.pO2Atm !== null ? `(${record.pO2Atm})` : ''}
            </div>
          </div>
          <div className="rounded border border-slate-200 bg-slate-50 p-2.5">
            <div className="text-slate-500">Flow U / Dir</div>
            <div className="mt-0.5 font-semibold text-slate-900">
              {record.velocityCmS !== null
                ? `${record.velocityCmS} cm/s`
                : record.uMinCmS !== null
                  ? `Umin ${record.uMinCmS}`
                  : '—'}{' '}
              {record.flowDirection ? translateFlowLabel(record.flowDirection, language) : ''}
            </div>
          </div>
          <div className="rounded border border-slate-200 bg-slate-50 p-2.5">
            <div className="text-slate-500">Vf / K / Cool</div>
            <div className="mt-0.5 font-semibold text-slate-900">
              {record.vfMmS !== null
                ? `${record.vfMmS} mm/s`
                : record.kHotMm2S !== null
                  ? `K=${record.kHotMm2S} mm²/s`
                  : '—'}
            </div>
          </div>
        </div>

        {/* Scientific Alert & Validity */}
        <div className="space-y-3 text-sm">
          {record.scientificAlert && (
            <div className="rounded-md border border-amber-200 bg-amber-50 p-3.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                {language === 'fr' ? 'Alerte scientifique' : 'Scientific Alert'}
              </div>
              <p className="mt-1 text-slate-800">
                {translateCsvField(record.scientificAlert, language)}
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
            <div className="rounded border border-slate-200 p-3 space-y-1">
              <div className="font-semibold text-slate-500">Verification Status</div>
              <div className="text-slate-900">
                {translateCsvField(record.verificationStatus, language) || '—'}
              </div>
            </div>
            <div className="rounded border border-slate-200 p-3 space-y-1">
              <div className="font-semibold text-slate-500">Validity Domain</div>
              <div className="text-slate-900">
                {translateCsvField(record.validityDomain, language) || '—'}
              </div>
            </div>
          </div>

          {record.initialObservation && (
            <div>
              <div className="text-xs font-semibold text-slate-500">
                Observation / Reference Conditions
              </div>
              <p className="mt-1 text-slate-700">
                {translateCsvField(record.initialObservation, language)}
                {record.referenceConditions ? ` (${record.referenceConditions})` : ''}
              </p>
            </div>
          )}

          {record.provenanceLimits && (
            <div>
              <div className="text-xs font-semibold text-slate-500">
                Provenance Limits
              </div>
              <p className="mt-1 text-xs text-slate-600">{record.provenanceLimits}</p>
            </div>
          )}

          {record.originalFormulas && (
            <div>
              <div className="text-xs font-semibold text-slate-500">
                Legacy Workbook Formulas
              </div>
              <pre className="mt-1 overflow-x-auto rounded border border-slate-200 bg-slate-900 p-3 font-mono text-[11px] text-slate-100">
                {record.originalFormulas}
              </pre>
            </div>
          )}
        </div>

        {/* External Links */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4">
          <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
            {record.nasaPsiUrl && (
              <a
                href={record.nasaPsiUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-blue-700 hover:underline"
              >
                <span>NASA PSI Investigation</span>
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            )}
            {record.publicationUrl && (
              <a
                href={record.publicationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-blue-700 hover:underline"
              >
                <span>Primary Publication / Standard</span>
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-md bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800"
          >
            {copy.closeModal}
          </button>
        </div>
      </div>
    </div>
  );
}
