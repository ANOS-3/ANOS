import type { CopyDictionary } from '../i18n/translations';
import type {
  HabitatQuery,
  HonestAssessment,
  HonestVerdictLevel,
  Language,
  MicrogravityRecord,
} from '../types/fireSafety';

interface HonestVerdictPanelProps {
  copy: CopyDictionary;
  language: Language;
  query: HabitatQuery;
  assessment: HonestAssessment;
  onSelectRecord: (record: MicrogravityRecord) => void;
}

const VERDICT_TONES: Record<
  HonestVerdictLevel,
  { container: string; glyphText: string }
> = {
  CRITICAL_PROPAGATION: {
    container: 'border-rose-200 bg-rose-50/70',
    glyphText: 'text-rose-700',
  },
  COOL_FLAME_INSTABILITY: {
    container: 'border-amber-200 bg-amber-50/70',
    glyphText: 'text-amber-700',
  },
  QUENCH_NOT_GUARANTEED: {
    container: 'border-amber-200 bg-amber-50/70',
    glyphText: 'text-amber-700',
  },
  OUT_OF_DOMAIN_UNKNOWN: {
    container: 'border-amber-200 bg-amber-50/70',
    glyphText: 'text-amber-700',
  },
  NO_PROPAGATION_OBSERVED: {
    container: 'border-emerald-200 bg-emerald-50/70',
    glyphText: 'text-emerald-700',
  },
};

export function HonestVerdictPanel({
  copy,
  language,
  query,
  assessment,
  onSelectRecord,
}: HonestVerdictPanelProps) {
  const verdictMeta = copy.verdictLabels[assessment.verdictLevel];
  const tone = VERDICT_TONES[assessment.verdictLevel];
  const closest = assessment.closestExperimentalTrial?.record ?? null;

  const closestMeasureText = closest
    ? closest.vfMmS !== null
      ? `${closest.vfMmS.toFixed(2)} mm/s`
      : closest.kHotMm2S !== null
        ? `${closest.kHotMm2S.toFixed(2)} mm²/s`
        : '0.00 mm/s'
    : 'N/A';

  return (
    <section
      aria-label="Honest fire safety verdict"
      className="rounded-lg border border-slate-200 bg-white p-6 space-y-6"
    >
      {/* Primary Verdict Header */}
      <div className={`rounded-md border p-4 ${tone.container}`}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <div className={`flex items-center gap-2 text-base font-semibold ${tone.glyphText}`}>
              <span aria-hidden="true">{verdictMeta.glyph}</span>
              <span>{verdictMeta.title}</span>
            </div>
            <p className="text-sm text-slate-700">{verdictMeta.subtitle}</p>
          </div>
          {closest && (
            <button
              type="button"
              onClick={() => onSelectRecord(closest)}
              className="whitespace-nowrap shrink-0 rounded-md border border-slate-300 bg-white px-3 py-1.5 font-mono text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              {closest.id} · {closest.mission}
            </button>
          )}
        </div>
      </div>

      {/* 4-Column Tabular Telemetry Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-md border border-slate-200 bg-slate-50/60 p-3.5">
          <div className="text-xs font-medium text-slate-500">{copy.kpiPO2}</div>
          <div className="mt-1 flex items-baseline">
            <span className="font-mono text-2xl font-semibold tabular-nums text-slate-900">
              {assessment.pO2Atm.toFixed(3)}
            </span>
            <span className="ml-1.5 font-mono text-xs uppercase text-slate-500">
              atm
            </span>
          </div>
          <div className="mt-1 font-mono text-[11px] tabular-nums text-slate-500">
            {query.o2Percent.toFixed(1)}% O₂ × {query.pressureAtm.toFixed(2)} atm
          </div>
        </div>

        <div className="rounded-md border border-slate-200 bg-slate-50/60 p-3.5">
          <div className="text-xs font-medium text-slate-500">
            {copy.kpiDeltaLoi}
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="font-mono text-2xl font-semibold tabular-nums text-slate-900">
              {assessment.deltaO2Pts !== null
                ? `${assessment.deltaO2Pts > 0 ? '+' : ''}${assessment.deltaO2Pts.toFixed(1)}`
                : 'N/A'}
            </span>
            {assessment.deltaO2Pts !== null && (
              <span className="ml-1.5 font-mono text-xs uppercase text-slate-500">
                pts
              </span>
            )}
          </div>
          <div className="mt-1 font-mono text-[11px] tabular-nums text-slate-500">
            {assessment.loiO2Threshold !== null
              ? `LOI ~ ${assessment.loiO2Threshold}% · Umin ~ ${assessment.uMinThreshold} cm/s`
              : language === 'fr'
                ? 'Matériau absent de la matrice'
                : 'Unlisted in LOI matrix'}
          </div>
        </div>

        <div className="rounded-md border border-slate-200 bg-slate-50/60 p-3.5">
          <div className="text-xs font-medium text-slate-500">
            {copy.kpiAnalogRate}
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="font-mono text-2xl font-semibold tabular-nums text-slate-900">
              {closestMeasureText}
            </span>
          </div>
          <div className="mt-1 font-mono text-[11px] tabular-nums text-slate-500 truncate">
            {closest
              ? `${closest.id} (${assessment.closestExperimentalTrial?.similarityScore}% match)`
              : '—'}
          </div>
        </div>

        <div className="rounded-md border border-slate-200 bg-slate-50/60 p-3.5">
          <div className="text-xs font-medium text-slate-500">
            {copy.kpiConfidence}
          </div>
          <div className="mt-1 text-sm font-semibold text-slate-900">
            {assessment.confidenceLabel}
          </div>
          <div className="mt-1 font-mono text-[11px] tabular-nums text-slate-500">
            {assessment.domainViolations.length}{' '}
            {language === 'fr' ? 'écarts domaine' : 'domain gaps'}
          </div>
        </div>
      </div>

      {/* Legacy Model vs Honest Audit Comparison */}
      <div>
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
          {copy.legacyVsHonestHeading}
        </h3>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="rounded-md border border-slate-200 bg-slate-50/60 p-4 space-y-1.5">
            <div className="text-xs font-medium text-slate-500">
              {copy.legacyColLabel}
            </div>
            <div className="text-sm font-semibold text-slate-900">
              {assessment.legacyComparison.legacyStatus}
            </div>
            <div className="font-mono text-xs tabular-nums text-slate-600">
              {assessment.legacyComparison.legacyVfMmS !== null
                ? `Vf formula = ${assessment.legacyComparison.legacyVfMmS} mm/s (ad hoc)`
                : 'No Vf estimate possible'}
            </div>
          </div>

          <div className="rounded-md border border-slate-200 bg-white p-4 space-y-1.5">
            <div className="text-xs font-medium text-slate-500">
              {copy.honestColLabel}
            </div>
            <div className="text-sm font-semibold text-slate-900">
              {verdictMeta.title}
            </div>
            <div className="font-mono text-xs tabular-nums text-slate-600">
              {assessment.estimatedVfRange
                ? `Measured NASA range: ${assessment.estimatedVfRange.min.toFixed(2)}–${assessment.estimatedVfRange.max.toFixed(2)} mm/s (${assessment.estimatedVfRange.basisIds.join(', ')})`
                : language === 'fr'
                  ? 'Aucune mesure Vf directe pour ce matériau/phase'
                  : 'No direct Vf measurement for this material/phase'}
            </div>
          </div>
        </div>
      </div>

      {/* Domain Violations & Epistemic Caveats */}
      {(assessment.domainViolations.length > 0 ||
        assessment.epistemicCaveats.length > 0 ||
        assessment.legacyComparison.divergenceWarnings.length > 0) && (
        <div className="border-t border-slate-200 pt-4">
          <h3 className="mb-2.5 text-xs font-semibold uppercase tracking-wider text-slate-500">
            {copy.domainAuditHeading}
          </h3>
          <ul className="space-y-2 text-sm text-slate-700">
            {assessment.domainViolations.map((item, idx) => (
              <li key={`dv-${idx}`} className="flex items-start gap-2">
                <span className="mt-0.5 font-mono text-xs font-semibold text-rose-700">
                  ▲
                </span>
                <span>{item}</span>
              </li>
            ))}
            {assessment.epistemicCaveats.map((item, idx) => (
              <li key={`ec-${idx}`} className="flex items-start gap-2">
                <span className="mt-0.5 font-mono text-xs font-semibold text-amber-700">
                  !
                </span>
                <span>{item}</span>
              </li>
            ))}
            {assessment.legacyComparison.divergenceWarnings.map((item, idx) => (
              <li key={`lw-${idx}`} className="flex items-start gap-2">
                <span className="mt-0.5 font-mono text-xs font-semibold text-blue-700">
                  Δ
                </span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
