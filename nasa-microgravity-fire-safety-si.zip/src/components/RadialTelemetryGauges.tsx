import type {
  DomainCheckItem,
} from '../lib/fireSafetyEngine';
import type { HabitatQuery, HonestAssessment, Language } from '../types/fireSafety';

interface RadialTelemetryGaugesProps {
  query: HabitatQuery;
  assessment: HonestAssessment;
  domainChecks: { validCount: number; total: number; checks: DomainCheckItem[] };
  language: Language;
}

function CircularGauge({
  value,
  max,
  centerValue,
  centerUnit,
  title,
  subtitle,
  strokeColor,
}: {
  value: number;
  max: number;
  centerValue: string;
  centerUnit: string;
  title: string;
  subtitle: string;
  strokeColor: string;
}) {
  const size = 88;
  const strokeWidth = 7;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.max(0, Math.min(1, value / max));
  const dashOffset = circumference * (1 - pct);

  return (
    <div className="flex flex-col items-center rounded-md border border-slate-200 bg-white p-3 text-center">
      <div className="relative h-[88px] w-[88px]">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#E2E8F0"
            strokeWidth={strokeWidth}
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={strokeColor}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-mono text-base font-bold tabular-nums leading-none text-slate-900">
            {centerValue}
          </span>
          <span className="mt-0.5 font-mono text-[10px] text-slate-500">
            {centerUnit}
          </span>
        </div>
      </div>
      <div className="mt-2 text-xs font-semibold text-slate-900">{title}</div>
      <div className="mt-0.5 font-mono text-[11px] tabular-nums text-slate-500 truncate max-w-full">
        {subtitle}
      </div>
    </div>
  );
}

export function RadialTelemetryGauges({
  query,
  assessment,
  domainChecks,
  language,
}: RadialTelemetryGaugesProps) {
  const isFr = language === 'fr';
  const o2Color =
    assessment.verdictLevel === 'CRITICAL_PROPAGATION'
      ? '#DC2626'
      : assessment.verdictLevel === 'NO_PROPAGATION_OBSERVED'
        ? '#059669'
        : '#D97706';

  const uColor =
    query.velocityCmS >= 40
      ? '#0284C7'
      : assessment.uMinThreshold !== null && query.velocityCmS < assessment.uMinThreshold
        ? '#D97706'
        : '#2563EB';

  const domainColor =
    domainChecks.validCount === 4
      ? '#059669'
      : domainChecks.validCount >= 2
        ? '#D97706'
        : '#DC2626';

  return (
    <div className="grid grid-cols-3 gap-2.5" aria-label="Telemetry radial gauges">
      <CircularGauge
        value={query.o2Percent}
        max={40}
        centerValue={`${query.o2Percent.toFixed(1)}%`}
        centerUnit={`pO₂ ${assessment.pO2Atm.toFixed(2)}`}
        title={isFr ? 'Oxygène & pO₂' : 'Oxygen & pO₂'}
        subtitle={
          assessment.loiO2Threshold !== null
            ? `LOI ~ ${assessment.loiO2Threshold}%`
            : isFr
              ? 'LOI inconnu'
              : 'LOI unknown'
        }
        strokeColor={o2Color}
      />

      <CircularGauge
        value={query.velocityCmS}
        max={50}
        centerValue={`${query.velocityCmS.toFixed(0)}`}
        centerUnit="cm/s"
        title={isFr ? 'Flux d’Air U' : 'Airflow U'}
        subtitle={
          query.velocityCmS >= 40
            ? isFr
              ? 'Zone blowoff'
              : 'Blowoff zone'
            : assessment.uMinThreshold !== null
              ? `Umin ${assessment.uMinThreshold} cm/s`
              : query.flowDirection
        }
        strokeColor={uColor}
      />

      <CircularGauge
        value={domainChecks.validCount}
        max={domainChecks.total}
        centerValue={`${domainChecks.validCount}/${domainChecks.total}`}
        centerUnit={isFr ? 'validé' : 'verified'}
        title={isFr ? 'Couverture NASA' : 'NASA Validity'}
        subtitle={
          domainChecks.validCount < domainChecks.total
            ? isFr
              ? 'Extrapolation'
              : 'Extrapolated'
            : isFr
              ? 'Dans domaine'
              : 'In domain'
        }
        strokeColor={domainColor}
      />
    </div>
  );
}
