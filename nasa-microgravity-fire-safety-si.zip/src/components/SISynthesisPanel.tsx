import type { CopyDictionary } from '../i18n/translations';
import type { MicrogravityRecord, SISynthesis } from '../types/fireSafety';

interface SISynthesisPanelProps {
  copy: CopyDictionary;
  synthesis: SISynthesis | null;
  isLoading: boolean;
  error: string | null;
  recordsById: Map<string, MicrogravityRecord>;
  onSelectRecord: (record: MicrogravityRecord) => void;
  onRetry: () => void;
}

export function SISynthesisPanel({
  copy,
  synthesis,
  isLoading,
  error,
  recordsById,
  onSelectRecord,
  onRetry,
}: SISynthesisPanelProps) {
  return (
    <section
      aria-label={copy.siSynthesisHeading}
      className="rounded-lg border border-slate-200 bg-white p-6 space-y-5"
    >
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            {copy.siSynthesisHeading}
          </h2>
          {synthesis && (
            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>{synthesis.modelName}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                {new Date(synthesis.generatedAt).toLocaleTimeString()}
              </span>
              {isLoading && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-blue-700 font-medium">
                    Refining with SI...
                  </span>
                </>
              )}
            </div>
          )}
        </div>

        {synthesis?.citedRecordIds && synthesis.citedRecordIds.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5">
            {synthesis.citedRecordIds.map((id) => {
              const rec = recordsById.get(id);
              if (!rec) return null;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onSelectRecord(rec)}
                  className="rounded border border-slate-300 bg-slate-50 px-2 py-1 font-mono text-xs font-medium text-slate-700 hover:border-blue-600 hover:text-blue-700 transition-colors"
                >
                  {id}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {isLoading && !synthesis && (
        <div className="space-y-3 py-2" aria-busy="true" aria-live="polite">
          <div className="h-4 w-3/4 animate-pulse rounded bg-slate-200" />
          <div className="h-4 w-full animate-pulse rounded bg-slate-200" />
          <div className="h-4 w-5/6 animate-pulse rounded bg-slate-200" />
          <div className="grid grid-cols-1 gap-4 pt-3 md:grid-cols-2">
            <div className="h-24 animate-pulse rounded bg-slate-100" />
            <div className="h-24 animate-pulse rounded bg-slate-100" />
          </div>
        </div>
      )}

      {error && !synthesis && (
        <div className="rounded-md border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800 flex items-center justify-between gap-4">
          <span>{error}</span>
          <button
            type="button"
            onClick={onRetry}
            className="whitespace-nowrap shrink-0 rounded border border-rose-300 bg-white px-3 py-1.5 text-xs font-medium text-rose-800 hover:bg-rose-100"
          >
            Retry
          </button>
        </div>
      )}

      {synthesis && (
        <div className="space-y-5">
          {synthesis.notice && (
            <p className="text-xs text-slate-500 border border-slate-200 bg-slate-50 rounded-md px-3 py-2">
              {synthesis.notice}
            </p>
          )}

          <div className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              {copy.siDirectAnswer}
            </h3>
            <p className="text-base font-medium leading-relaxed text-slate-900">
              {synthesis.directAnswer}
            </p>
            <p className="text-sm leading-relaxed text-slate-700">
              {synthesis.honestRiskSummary}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 border-t border-slate-200 pt-5 md:grid-cols-2">
            <div className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {copy.siEvidence}
              </h3>
              <ul className="space-y-2 text-sm text-slate-700">
                {synthesis.evidenceBreakdown.map((item, idx) => (
                  <li key={`ev-${idx}`} className="flex items-start gap-2">
                    <span className="mt-1 font-mono text-xs text-blue-600">
                      0{idx + 1}.
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {copy.siUnknowns}
              </h3>
              <ul className="space-y-2 text-sm text-slate-700">
                {synthesis.whatWeDoNotKnow.map((item, idx) => (
                  <li key={`uk-${idx}`} className="flex items-start gap-2">
                    <span className="mt-0.5 font-mono text-xs font-semibold text-amber-700">
                      ▲
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-200 pt-4">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
              {copy.siRecommendations}
            </h3>
            <ul className="grid grid-cols-1 gap-3 md:grid-cols-3">
              {synthesis.safetyRecommendations.map((rec, idx) => (
                <li
                  key={`rec-${idx}`}
                  className="rounded-md border border-slate-200 bg-slate-50/70 p-3 text-xs leading-relaxed text-slate-700"
                >
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </section>
  );
}
