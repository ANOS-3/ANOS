import type { Language } from '../types/fireSafety';

export type SlideView = 'cockpit' | 'archive' | 'audit';

interface TopBarProps {
  language: Language;
  activeView: SlideView;
  onSelectView: (view: SlideView) => void;
  onFocusQuestion: () => void;
}

export function TopBar({
  language,
  activeView,
  onSelectView,
  onFocusQuestion,
}: TopBarProps) {
  const isFr = language === 'fr';
  const navItems: { id: SlideView; label: string }[] = [
    { id: 'cockpit', label: isFr ? 'Cockpit Visuel' : 'Visual Cockpit' },
    { id: 'archive', label: isFr ? 'Vision Profonde (39)' : 'Deep Vision (39)' },
    { id: 'audit', label: isFr ? 'Audit Modèle Hérité' : 'Legacy Model Audit' },
  ];

  return (
    <header className="border-b border-slate-200 bg-white shrink-0">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-8 px-4 py-2.5 lg:px-6">
        <button
          type="button"
          onClick={() => onSelectView('cockpit')}
          className="whitespace-nowrap shrink-0 text-base font-semibold tracking-tight text-slate-900 text-left"
        >
          Microgravity Fire Lab
        </button>

        <nav
          aria-label="Dashboard slides"
          className="flex items-center gap-6 text-sm font-medium text-slate-600"
        >
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectView(item.id)}
                className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                  isActive
                    ? 'text-blue-700 underline underline-offset-8 decoration-2 font-semibold'
                    : 'hover:text-slate-900 hover:underline underline-offset-8'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="shrink-0">
          <button
            type="button"
            onClick={() => {
              onSelectView('cockpit');
              onFocusQuestion();
            }}
            className="whitespace-nowrap shrink-0 rounded-md bg-blue-600 px-3.5 py-1.5 text-xs font-medium text-white hover:bg-blue-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 transition-colors"
          >
            {isFr ? 'Poser une Question' : 'Ask SI Engine'}
          </button>
        </div>
      </div>
    </header>
  );
}
