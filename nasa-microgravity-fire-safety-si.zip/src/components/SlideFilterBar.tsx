import type { RefObject } from 'react';
import { Send } from 'lucide-react';
import { MISSION_PRESETS } from '../data/presets';
import { MATERIAL_CATALOG, UNKNOWN_MATERIAL_KEY } from '../lib/fireSafetyEngine';
import type {
  FlowDirection,
  GravityEnvironment,
  HabitatQuery,
  Language,
} from '../types/fireSafety';

interface SlideFilterBarProps {
  language: Language;
  query: HabitatQuery;
  isAnalyzing: boolean;
  activePresetId: string | null;
  questionInputRef: RefObject<HTMLInputElement | null>;
  onUpdateQuery: (patch: Partial<HabitatQuery>) => void;
  onSelectPreset: (presetId: string) => void;
  onAskQuestion: () => void;
}

export function SlideFilterBar({
  language,
  query,
  isAnalyzing,
  activePresetId,
  questionInputRef,
  onUpdateQuery,
  onSelectPreset,
  onAskQuestion,
}: SlideFilterBarProps) {
  const isFr = language === 'fr';
  const flowDirections: FlowDirection[] = ['Concurrent', 'Opposé', 'Stagnant'];
  const gravities: GravityEnvironment[] = ['0g', 'lunar', 'mars'];

  return (
    <section
      aria-label={isFr ? 'Question astronaute et filtres habitat' : 'Astronaut question and habitat filters'}
      className="border-b border-slate-200 bg-white px-4 py-2.5 lg:px-6"
    >
      <div className="mx-auto max-w-[1440px] space-y-2">
        {/* Row 1: Astronaut Question Input + Quick Scenarios */}
        <div className="flex flex-col gap-2 lg:flex-row lg:items-center">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onAskQuestion();
            }}
            className="flex flex-1 items-center gap-2"
          >
            <label htmlFor="astronaut-question-input" className="sr-only">
              {isFr ? 'Question sécurité incendie' : 'Fire safety question'}
            </label>
            <input
              id="astronaut-question-input"
              ref={questionInputRef}
              type="text"
              value={query.questionText}
              onChange={(e) => onUpdateQuery({ questionText: e.target.value })}
              placeholder={
                isFr
                  ? 'Mon habitat lunaire utilise du tissu X, O₂ 34%, flux d’air concurrent 15 cm/s. Quel est le risque incendie ?'
                  : 'My lunar habitat uses Fabric X, 34% O₂, 0.6 atm, 15 cm/s concurrent airflow. What is the fire risk?'
              }
              className="h-9 flex-1 rounded-md border border-slate-300 bg-slate-50 px-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none"
            />
            <button
              type="submit"
              disabled={isAnalyzing}
              className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap shrink-0 rounded-md bg-blue-600 px-3.5 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-60 transition-colors"
            >
              <Send className="h-3.5 w-3.5" aria-hidden="true" />
              <span>
                {isAnalyzing
                  ? isFr
                    ? 'Analyse...'
                    : 'Analyzing...'
                  : isFr
                    ? 'Répondre'
                    : 'Analyze'}
              </span>
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-1.5">
            {MISSION_PRESETS.slice(0, 4).map((preset) => {
              const active = activePresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onSelectPreset(preset.id)}
                  className={`whitespace-nowrap rounded border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                    active
                      ? 'border-blue-600 bg-blue-50 text-blue-800'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {isFr ? preset.labelFr : preset.labelEn}
                </button>
              );
            })}
          </div>
        </div>

        {/* Row 2: Live Parametric Filters */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <label htmlFor="filter-material" className="font-medium text-slate-500">
              {isFr ? 'Matériau' : 'Material'}:
            </label>
            <select
              id="filter-material"
              value={query.materialKey}
              onChange={(e) => onUpdateQuery({ materialKey: e.target.value })}
              className="h-7 max-w-[210px] rounded border border-slate-300 bg-white px-2 text-xs font-medium text-slate-900 focus:border-blue-600 focus:outline-none"
            >
              <option value={UNKNOWN_MATERIAL_KEY}>
                {isFr ? 'Inconnu / Tissu X' : 'Unknown / Fabric X'}
              </option>
              {MATERIAL_CATALOG.map((m) => (
                <option key={m.loiKey} value={m.loiKey}>
                  {isFr ? m.labelFr : m.labelEn}
                </option>
              ))}
            </select>
            {query.materialKey === UNKNOWN_MATERIAL_KEY && (
              <input
                type="text"
                aria-label={isFr ? 'Nom du matériau' : 'Custom material name'}
                value={query.customMaterialName}
                onChange={(e) => onUpdateQuery({ customMaterialName: e.target.value })}
                placeholder={isFr ? 'Tissu X' : 'Fabric X'}
                className="h-7 w-24 rounded border border-slate-300 bg-slate-50 px-2 text-xs text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            )}
          </div>

          <div className="flex items-center gap-1.5">
            <label htmlFor="filter-o2" className="font-medium text-slate-500">
              O₂:
            </label>
            <input
              id="filter-o2"
              type="range"
              min={10}
              max={40}
              step={0.5}
              value={query.o2Percent}
              onChange={(e) => onUpdateQuery({ o2Percent: Number(e.target.value) })}
              className="w-20 accent-blue-600"
            />
            <span className="w-11 font-mono font-semibold tabular-nums text-slate-900">
              {query.o2Percent.toFixed(1)}%
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <label htmlFor="filter-pressure" className="font-medium text-slate-500">
              P:
            </label>
            <input
              id="filter-pressure"
              type="range"
              min={0.3}
              max={1.5}
              step={0.05}
              value={query.pressureAtm}
              onChange={(e) => onUpdateQuery({ pressureAtm: Number(e.target.value) })}
              className="w-16 accent-blue-600"
            />
            <span className="whitespace-nowrap font-mono font-semibold tabular-nums text-slate-900">
              {query.pressureAtm.toFixed(2)} atm
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <label htmlFor="filter-velocity" className="font-medium text-slate-500">
              U:
            </label>
            <input
              id="filter-velocity"
              type="range"
              min={0}
              max={55}
              step={0.5}
              value={query.velocityCmS}
              onChange={(e) => onUpdateQuery({ velocityCmS: Number(e.target.value) })}
              className="w-20 accent-blue-600"
            />
            <span className="whitespace-nowrap font-mono font-semibold tabular-nums text-slate-900">
              {query.velocityCmS.toFixed(1)} cm/s
            </span>
          </div>

          <div
            role="group"
            aria-label={isFr ? 'Direction flux' : 'Flow direction'}
            className="flex items-center rounded border border-slate-200 bg-slate-100 p-0.5"
          >
            {flowDirections.map((dir) => (
              <button
                key={dir}
                type="button"
                onClick={() => onUpdateQuery({ flowDirection: dir })}
                className={`whitespace-nowrap rounded px-2 py-0.5 text-[11px] font-medium transition-colors ${
                  query.flowDirection === dir
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {dir === 'Opposé' && !isFr ? 'Opposed' : dir}
              </button>
            ))}
          </div>

          <div
            role="group"
            aria-label={isFr ? 'Gravité' : 'Gravity'}
            className="flex items-center rounded border border-slate-200 bg-slate-100 p-0.5"
          >
            {gravities.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => onUpdateQuery({ gravity: g })}
                className={`whitespace-nowrap rounded px-2 py-0.5 text-[11px] font-medium transition-colors ${
                  query.gravity === g
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {g === '0g' ? '0g' : g === 'lunar' ? (isFr ? '1/6g Lune' : '1/6g Lunar') : '0.38g Mars'}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
