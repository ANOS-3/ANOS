import { useState } from 'react';
import type { CopyDictionary } from '../i18n/translations';
import { translateMaterialLabel } from '../lib/fireSafetyEngine';
import type {
  HabitatQuery,
  HonestAssessment,
  Language,
  MicrogravityRecord,
} from '../types/fireSafety';

interface FlammabilityRegimeMapProps {
  copy: CopyDictionary;
  language?: Language;
  records: MicrogravityRecord[];
  query: HabitatQuery;
  assessment: HonestAssessment;
  onSelectRecord: (record: MicrogravityRecord) => void;
}

const SVG_W = 680;
const SVG_H = 278;
const PAD = { top: 18, right: 20, bottom: 40, left: 48 };
const PLOT_W = SVG_W - PAD.left - PAD.right;
const PLOT_H = SVG_H - PAD.top - PAD.bottom;

const MAX_U = 52;
const MIN_O2 = 10;
const MAX_O2 = 38;

function xScale(u: number): number {
  const clamped = Math.max(0, Math.min(MAX_U, u));
  return PAD.left + (clamped / MAX_U) * PLOT_W;
}

function yScale(o2: number): number {
  const clamped = Math.max(MIN_O2, Math.min(MAX_O2, o2));
  return PAD.top + ((MAX_O2 - clamped) / (MAX_O2 - MIN_O2)) * PLOT_H;
}

type PointKind = 'active' | 'quench' | 'blowoff' | 'cool_flame';

function classifyExperiment(r: MicrogravityRecord): PointKind {
  if (r.rowType === 'Essai goutte') {
    return r.coolFlame.toLowerCase().startsWith('oui') ? 'cool_flame' : 'active';
  }
  const obs = r.initialObservation.toLowerCase();
  if (obs.includes('blowoff') || obs.includes('soufflage')) return 'blowoff';
  if ((r.vfMmS !== null && r.vfMmS === 0) || obs.includes('extinction') || obs.includes('ininflammable')) {
    return 'quench';
  }
  return 'active';
}

export function FlammabilityRegimeMap({
  copy,
  language = 'en',
  records,
  query,
  assessment,
  onSelectRecord,
}: FlammabilityRegimeMapProps) {
  const [hoveredRecord, setHoveredRecord] = useState<MicrogravityRecord | null>(null);
  const [missionFilter, setMissionFilter] = useState<'ALL' | 'SAFFIRE' | 'BASS-II' | 'FLEX'>('ALL');
  const isFr = language === 'fr';

  const experimentalPoints = records.filter((r) => {
    if (r.rowType !== 'Essai solide' && r.rowType !== 'Essai goutte') return false;
    if (r.o2Percent === null) return false;
    if (missionFilter === 'SAFFIRE') return r.mission.startsWith('SAFFIRE');
    if (missionFilter === 'BASS-II') return r.mission === 'BASS-II';
    if (missionFilter === 'FLEX') return r.mission === 'FLEX';
    return true;
  });

  // Bucket overlapping (U, O2) coordinates so every experiment (e.g. MG-003/004 or FLEX at U=0, O2=21%) is clickable
  const coordBuckets = new Map<string, MicrogravityRecord[]>();
  for (const rec of experimentalPoints) {
    const key = `${rec.velocityCmS ?? 0}|${rec.o2Percent}`;
    const bucket = coordBuckets.get(key);
    if (bucket) bucket.push(rec);
    else coordBuckets.set(key, [rec]);
  }
  const plottedPoints = experimentalPoints.map((rec) => {
    const u = rec.velocityCmS ?? 0;
    const o2 = rec.o2Percent!;
    const baseCx = xScale(u);
    const baseCy = yScale(o2);
    const bucket = coordBuckets.get(`${u}|${o2}`) ?? [rec];
    if (bucket.length === 1) {
      return { rec, baseCx, baseCy, cx: baseCx, cy: baseCy, isOffset: false };
    }
    const idx = bucket.indexOf(rec);
    const angle = (2 * Math.PI * idx) / bucket.length - Math.PI / 2;
    const radiusPx = bucket.length >= 4 ? 10 : 7;
    return {
      rec,
      baseCx,
      baseCy,
      cx: Math.max(PAD.left + 6, Math.min(PAD.left + PLOT_W - 6, baseCx + Math.cos(angle) * radiusPx)),
      cy: Math.max(PAD.top + 6, Math.min(PAD.top + PLOT_H - 6, baseCy + Math.sin(angle) * radiusPx)),
      isOffset: true,
    };
  });

  const targetX = xScale(query.velocityCmS);
  const targetY = yScale(query.o2Percent);
  const loiY = assessment.loiO2Threshold !== null ? yScale(assessment.loiO2Threshold) : null;
  const uMinX = assessment.uMinThreshold !== null ? xScale(assessment.uMinThreshold) : null;

  const uTicks = [0, 10, 20, 30, 40, 50];
  const o2Ticks = [12, 16, 21, 26, 30, 34, 38];

  return (
    <section
      id="regime-map"
      aria-label={copy.regimeMapHeading}
      className="flex flex-1 flex-col justify-between rounded-lg border border-slate-200 bg-white p-4 space-y-2.5"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-600">
            {isFr ? 'Carte Régimes : O₂ (%) vs Flux d’Air U (cm/s)' : 'Flammability Map: O₂ (%) vs. Airflow U (cm/s)'}
          </h2>
        </div>

        <div
          role="group"
          aria-label="Filter map by NASA mission"
          className="flex items-center gap-0.5 rounded border border-slate-200 bg-slate-100 p-0.5"
        >
          {(['ALL', 'SAFFIRE', 'BASS-II', 'FLEX'] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMissionFilter(m)}
              className={`whitespace-nowrap rounded px-2 py-0.5 text-[11px] font-medium transition-colors ${
                missionFilter === m
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {m === 'ALL' ? 'All (20)' : m}
            </button>
          ))}
        </div>
      </div>

      <div className="relative flex-1 min-h-0">
        <svg
          viewBox={`0 0 ${SVG_W} ${SVG_H}`}
          className="w-full h-full max-h-[290px] select-none cursor-crosshair"
          role="img"
          aria-label="Microgravity O2 versus airflow velocity flammability map"
        >
          <defs>
            <pattern id="extrapolated-hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
              <rect width="8" height="8" fill="#FEF3C7" opacity="0.55" />
              <line x1="0" y1="0" x2="0" y2="8" stroke="#D97706" strokeWidth="1.5" opacity="0.35" />
            </pattern>
          </defs>

          <rect
            x={PAD.left}
            y={PAD.top}
            width={PLOT_W}
            height={PLOT_H}
            fill="#F8FAFC"
            stroke="#CBD5E1"
            strokeWidth={1}
          />

          {/* Regime Zones: Known material uses its LOI/Umin + domain validity (0g & ref pressure); Unknown shows no certified safe zone */}
          {(() => {
            const refP = query.materialKey === 'n-Décane (Goutte)' ? 0.5 : 1.0;
            const inDomainForSafe =
              query.gravity === '0g' && Math.abs(query.pressureAtm - refP) <= 0.1;

            if (loiY !== null) {
              return (
                <>
                  {/* Active Hazard Zone (O2 >= LOI & U >= Umin) */}
                  <rect
                    x={uMinX !== null ? uMinX : PAD.left}
                    y={PAD.top}
                    width={uMinX !== null ? Math.max(0, PAD.left + PLOT_W - uMinX) : PLOT_W}
                    height={Math.max(0, loiY - PAD.top)}
                    fill="#FEE2E2"
                    opacity={0.5}
                  />
                  {/* Radiative Quench Zone (O2 >= LOI & U < Umin) */}
                  {uMinX !== null && assessment.uMinThreshold! > 0 && (
                    <rect
                      x={PAD.left}
                      y={PAD.top}
                      width={Math.max(0, uMinX - PAD.left)}
                      height={Math.max(0, loiY - PAD.top)}
                      fill="#FEF3C7"
                      opacity={0.8}
                    />
                  )}
                  {/* Indicative Safe / No-Spread Zone (O2 < LOI): solid green ONLY in 0g & ref pressure, hatched amber when P/g extrapolated */}
                  <rect
                    x={PAD.left}
                    y={loiY}
                    width={PLOT_W}
                    height={Math.max(0, PAD.top + PLOT_H - loiY)}
                    fill={inDomainForSafe ? '#D1FAE5' : 'url(#extrapolated-hatch)'}
                    opacity={inDomainForSafe ? 0.78 : 1}
                  />
                </>
              );
            }

            return (
              <>
                {/* Unknown material: NEVER paint a green safe zone; show NASA hazard/uncertainty envelope */}
                <rect
                  x={PAD.left}
                  y={PAD.top}
                  width={PLOT_W}
                  height={Math.max(0, yScale(22.2) - PAD.top)}
                  fill="#FEE2E2"
                  opacity={0.48}
                />
                <rect
                  x={PAD.left}
                  y={yScale(22.2)}
                  width={PLOT_W}
                  height={Math.max(0, PAD.top + PLOT_H - yScale(22.2))}
                  fill="url(#extrapolated-hatch)"
                />
              </>
            );
          })()}

          {uTicks.map((u) => {
            const x = xScale(u);
            return (
              <g key={`ut-${u}`}>
                <line x1={x} y1={PAD.top} x2={x} y2={PAD.top + PLOT_H} stroke="#E2E8F0" strokeWidth={1} />
                <text x={x} y={PAD.top + PLOT_H + 15} textAnchor="middle" className="fill-slate-500 font-mono text-[10px]">
                  {u}
                </text>
              </g>
            );
          })}

          {o2Ticks.map((o2) => {
            const y = yScale(o2);
            return (
              <g key={`ot-${o2}`}>
                <line x1={PAD.left} y1={y} x2={PAD.left + PLOT_W} y2={y} stroke="#E2E8F0" strokeWidth={1} />
                <text x={PAD.left - 6} y={y + 3.5} textAnchor="end" className="fill-slate-500 font-mono text-[10px]">
                  {o2}%
                </text>
              </g>
            );
          })}

          {loiY !== null ? (
            (() => {
              const refP = query.materialKey === 'n-Décane (Goutte)' ? 0.5 : 1.0;
              const inDomainForSafe =
                query.gravity === '0g' && Math.abs(query.pressureAtm - refP) <= 0.1;
              return (
                <g>
                  <line
                    x1={PAD.left}
                    y1={loiY}
                    x2={PAD.left + PLOT_W}
                    y2={loiY}
                    stroke={inDomainForSafe ? '#059669' : '#D97706'}
                    strokeWidth={1.75}
                    strokeDasharray="6 4"
                  />
                  <text
                    x={xScale(42)}
                    y={loiY - 5}
                    textAnchor="end"
                    className={`${inDomainForSafe ? 'fill-emerald-800' : 'fill-amber-800'} font-mono text-[10px] font-semibold`}
                  >
                    LOI ≈ {assessment.loiO2Threshold}% (0g, {refP} atm)
                  </text>
                  <text
                    x={PAD.left + PLOT_W - 8}
                    y={PAD.top + PLOT_H - 8}
                    textAnchor="end"
                    className={`${inDomainForSafe ? 'fill-emerald-900' : 'fill-amber-900'} font-mono text-[10px] font-semibold`}
                  >
                    {inDomainForSafe
                      ? isFr
                        ? `Zone Sûre Indic. (< ${assessment.loiO2Threshold}% O₂ · 0g / ${refP} atm)`
                        : `Safe Ref. Zone (< ${assessment.loiO2Threshold}% O₂ · 0g / ${refP} atm)`
                      : isFr
                        ? `Hors domaine (${query.pressureAtm} atm / ${query.gravity}) — LOI 0g non valide`
                        : `Extrapolated (${query.pressureAtm} atm / ${query.gravity}) — 0g limit uncertified`}
                  </text>
                  <text
                    x={PAD.left + PLOT_W - 8}
                    y={PAD.top + 13}
                    textAnchor="end"
                    className="fill-rose-800 font-mono text-[10px] font-semibold"
                  >
                    {isFr ? 'Zone Risque Actif (O₂ ≥ LOI, U ≥ Umin)' : 'Active Hazard Zone (O₂ ≥ LOI, U ≥ Umin)'}
                  </text>
                </g>
              );
            })()
          ) : (
            <g>
              <line
                x1={PAD.left}
                y1={yScale(22.2)}
                x2={PAD.left + PLOT_W}
                y2={yScale(22.2)}
                stroke="#D97706"
                strokeWidth={1.25}
                strokeDasharray="4 4"
              />
              <text x={xScale(42)} y={yScale(22.2) - 4} textAnchor="end" className="fill-amber-800 font-mono text-[9.5px] font-semibold">
                Nomex III Ref. 22.2% (MG-025)
              </text>
              <line
                x1={PAD.left}
                y1={yScale(16.4)}
                x2={PAD.left + PLOT_W}
                y2={yScale(16.4)}
                stroke="#64748B"
                strokeWidth={1.25}
                strokeDasharray="6 4"
              />
              <text x={xScale(42)} y={yScale(16.4) - 4} textAnchor="end" className="fill-slate-700 font-mono text-[9.5px] font-semibold">
                SIBAL Ref. 16.4% (MG-021)
              </text>
              <text
                x={PAD.left + PLOT_W - 8}
                y={PAD.top + PLOT_H - 8}
                textAnchor="end"
                className="fill-amber-900 font-mono text-[10px] font-semibold"
              >
                {isFr
                  ? 'Matériau inconnu : aucune zone sûre certifiée (même à bas O₂)'
                  : 'Unknown Material: No Certified Safe Zone (even at low O₂)'}
              </text>
              <text
                x={PAD.left + PLOT_W - 8}
                y={PAD.top + 13}
                textAnchor="end"
                className="fill-rose-800 font-mono text-[10px] font-semibold"
              >
                {isFr ? 'Hors Bornes Textiles NASA (≥ 22.2% O₂)' : 'Above NASA Textile Bounds (≥ 22.2% O₂)'}
              </text>
            </g>
          )}

          {uMinX !== null && assessment.uMinThreshold! > 0 && (
            <g>
              <line
                x1={uMinX}
                y1={PAD.top}
                x2={uMinX}
                y2={PAD.top + PLOT_H}
                stroke="#D97706"
                strokeWidth={1.5}
                strokeDasharray="4 4"
              />
              <text x={uMinX + 5} y={PAD.top + 13} className="fill-amber-700 font-mono text-[10px] font-semibold">
                Umin {assessment.uMinThreshold}
              </text>
            </g>
          )}

          {plottedPoints.map(({ rec, baseCx, baseCy, cx, cy, isOffset }) => {
            const kind = classifyExperiment(rec);
            const isClosest = assessment.closestExperimentalTrial?.record.id === rec.id;

            return (
              <g
                key={rec.id}
                onMouseEnter={() => setHoveredRecord(rec)}
                onMouseLeave={() => setHoveredRecord(null)}
                onClick={() => onSelectRecord(rec)}
                className="cursor-pointer"
              >
                {isOffset && (
                  <line
                    x1={baseCx}
                    y1={baseCy}
                    x2={cx}
                    y2={cy}
                    stroke="#94A3B8"
                    strokeWidth={1}
                  />
                )}
                {isClosest && (
                  <circle cx={cx} cy={cy} r={10} fill="none" stroke="#2563EB" strokeWidth={1.5} strokeDasharray="3 2" />
                )}
                {kind === 'active' && (
                  <circle cx={cx} cy={cy} r={5} fill="#DC2626" stroke="#FFFFFF" strokeWidth={1.5} />
                )}
                {kind === 'quench' && (
                  <rect x={cx - 4.5} y={cy - 4.5} width={9} height={9} fill="#059669" stroke="#FFFFFF" strokeWidth={1.5} />
                )}
                {kind === 'blowoff' && (
                  <polygon
                    points={`${cx},${cy - 6} ${cx + 6},${cy} ${cx},${cy + 6} ${cx - 6},${cy}`}
                    fill="#0284C7"
                    stroke="#FFFFFF"
                    strokeWidth={1.5}
                  />
                )}
                {kind === 'cool_flame' && (
                  <polygon
                    points={`${cx},${cy - 5.5} ${cx + 5.5},${cy + 4.5} ${cx - 5.5},${cy + 4.5}`}
                    fill="#D97706"
                    stroke="#FFFFFF"
                    strokeWidth={1.5}
                  />
                )}
              </g>
            );
          })}

          {/* Habitat Operating Crosshair */}
          <g pointerEvents="none">
            <line x1={PAD.left} y1={targetY} x2={PAD.left + PLOT_W} y2={targetY} stroke="#2563EB" strokeWidth={1} strokeDasharray="2 3" opacity={0.75} />
            <line x1={targetX} y1={PAD.top} x2={targetX} y2={PAD.top + PLOT_H} stroke="#2563EB" strokeWidth={1} strokeDasharray="2 3" opacity={0.75} />
            <circle cx={targetX} cy={targetY} r={8} fill="none" stroke="#2563EB" strokeWidth={2} />
            <circle cx={targetX} cy={targetY} r={3} fill="#2563EB" />
            <text
              x={targetX + (query.velocityCmS > 36 ? -11 : 11)}
              y={targetY < PAD.top + 22 ? targetY + 17 : targetY - 10}
              textAnchor={query.velocityCmS > 36 ? 'end' : 'start'}
              stroke="#FFFFFF"
              strokeWidth={3.5}
              paintOrder="stroke"
              strokeLinejoin="round"
              className="fill-blue-700 font-mono text-[10px] font-semibold"
            >
              Habitat ({query.velocityCmS} cm/s, {query.o2Percent}%)
            </text>
          </g>

          <text x={PAD.left + PLOT_W / 2} y={SVG_H - 6} textAnchor="middle" className="fill-slate-500 text-[11px] font-medium">
            Airflow Velocity U (cm/s)
          </text>
          <text
            x={14}
            y={PAD.top + PLOT_H / 2}
            textAnchor="middle"
            transform={`rotate(-90, 14, ${PAD.top + PLOT_H / 2})`}
            className="fill-slate-500 text-[11px] font-medium"
          >
            O₂ (%)
          </text>
        </svg>
      </div>

      {/* Compact Legend + Hover Readout */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-[11px] text-slate-600">
        <div className="flex flex-wrap items-center gap-2.5">
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2.5 w-2.5 rounded-xs border border-emerald-600/50 bg-emerald-200" />
            {isFr ? 'Zone Sûre Réf.' : 'Safe Ref.'}
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2.5 w-2.5 rounded-xs border border-amber-500/50 bg-amber-100" />
            {isFr ? 'Zone Transition' : 'Quench/Margin'}
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2.5 w-2.5 rounded-xs border border-rose-500/50 bg-rose-100" />
            {isFr ? 'Zone Risque' : 'Hazard'}
          </span>
          <span className="text-slate-300" aria-hidden="true">|</span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-full bg-red-600" />
            {isFr ? 'Actif' : 'Active'}
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 bg-emerald-600" />
            {isFr ? 'Extinction' : 'Quench'}
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 rotate-45 bg-sky-600" />
            Blowoff
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 bg-amber-600" />
            {isFr ? 'Flamme Froide' : 'Cool Flame'}
          </span>
        </div>

        <div className="font-mono text-[11px] tabular-nums text-slate-800 truncate max-w-[360px]">
          {hoveredRecord
            ? `${hoveredRecord.id} · ${translateMaterialLabel(hoveredRecord.materialOriginal, language)} · ${hoveredRecord.o2Percent}% O₂ · ${hoveredRecord.pressureAtm ?? '—'} atm · U=${hoveredRecord.velocityCmS ?? 0}${hoveredRecord.vfMmS !== null ? ` · Vf ${hoveredRecord.vfMmS}` : hoveredRecord.kHotMm2S !== null ? ` · K ${hoveredRecord.kHotMm2S}` : ''}`
            : isFr
              ? 'Survolez/cliquez un essai NASA'
              : 'Hover or click a NASA point'}
        </div>
      </div>
    </section>
  );
}
