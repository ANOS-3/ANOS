import type { CopyDictionary } from '../i18n/translations';
import type { DomainCheckItem } from '../lib/fireSafetyEngine';
import type {
  HonestAssessment,
  HonestVerdictLevel,
  Language,
  MicrogravityRecord,
  SISynthesis,
} from '../types/fireSafety';

interface AstronautAnswerCardProps {
  copy: CopyDictionary;
  language: Language;
  assessment: HonestAssessment;
  domainChecks: DomainCheckItem[];
  synthesis: SISynthesis | null;
  isAnalyzing: boolean;
  onOpenFullBrief: () => void;
  recordsById: Map<string, MicrogravityRecord>;
  onSelectRecord: (record: MicrogravityRecord) => void;
}

const VERDICT_STYLE: Record<HonestVerdictLevel, { box: string; text: string }> = {
  CRITICAL_PROPAGATION: {
    box: 'border-rose-200 bg-rose-50',
    text: 'text-rose-800',
  },
  COOL_FLAME_INSTABILITY: {
    box: 'border-amber-200 bg-amber-50',
    text: 'text-amber-800',
  },
  QUENCH_NOT_GUARANTEED: {
    box: 'border-amber-200 bg-amber-50',
    text: 'text-amber-800',
  },
  OUT_OF_DOMAIN_UNKNOWN: {
    box: 'border-amber-200 bg-amber-50',
    text: 'text-amber-800',
  },
  NO_PROPAGATION_OBSERVED: {
    box: 'border-emerald-200 bg-emerald-50',
    text: 'text-emerald-800',
  },
};

export function AstronautAnswerCard({
  copy,
  language,
  assessment,
  domainChecks,
  synthesis,
  isAnalyzing,
  onOpenFullBrief,
  recordsById,
  onSelectRecord,
}: AstronautAnswerCardProps) {
  const isFr = language === 'fr';
  const meta = copy.verdictLabels[assessment.verdictLevel];
  const style = VERDICT_STYLE[assessment.verdictLevel];

  return (
    <section
      aria-label="Honest astronaut fire risk answer"
      className="flex flex-1 flex-col justify-between rounded-lg border border-slate-200 bg-white p-4 space-y-3"
    >
      <div className="space-y-3">
        {/* Verdict Strip */}
        <div className={`rounded-md border px-3 py-2.5 ${style.box}`}>
          <div className={`flex items-center justify-between gap-2 text-sm font-semibold ${style.text}`}>
            <span>
              <span aria-hidden="true" className="mr-1.5">
                {meta.glyph}
              </span>
              {meta.title}
            </span>
            {isAnalyzing && (
              <span className="font-mono text-[10px] font-medium uppercase">
                SI...
              </span>
            )}
          </div>
        </div>

        {/* Direct Concise Answer */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-slate-500">
            <span>{isFr ? 'Réponse Honnête SI' : 'Honest SI Answer'}</span>
            {synthesis && (
              <span className="font-mono font-normal lowercase text-slate-400">
                {synthesis.modelName}
              </span>
            )}
          </div>
          <p className="text-xs leading-relaxed text-slate-800">
            {synthesis?.directAnswer || meta.subtitle}
          </p>
        </div>

        {/* Visual Domain & Legacy Check Grid */}
        <div className="grid grid-cols-2 gap-1.5 pt-1">
          {domainChecks.map((chk) => (
            <div
              key={chk.key}
              className="rounded border border-slate-200 bg-slate-50/70 px-2.5 py-1.5"
            >
              <div className="flex items-center justify-between text-[11px] font-medium">
                <span className="text-slate-600">{chk.label}</span>
                <span className={chk.ok ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                  {chk.ok ? '● OK' : '▲ Gap'}
                </span>
              </div>
              <div className="mt-0.5 truncate font-mono text-[10px] text-slate-500">
                {chk.detail}
              </div>
            </div>
          ))}
        </div>

        {/* Legacy Comparison 1-liner */}
        <div className="rounded border border-slate-200 bg-slate-50 px-2.5 py-2 text-[11px]">
          <div className="flex items-center justify-between gap-2">
            <span className="font-medium text-slate-500">
              {isFr ? 'Modèle Tableur Hérité' : 'Legacy Excel Model'}:
            </span>
            <span className="font-mono font-semibold text-slate-800 truncate">
              {assessment.legacyComparison.legacyStatus}
            </span>
          </div>
        </div>
      </div>

      {/* Footer Citations + Full Brief Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 pt-2.5">
        <div className="flex flex-wrap items-center gap-1">
          {(synthesis?.citedRecordIds ?? []).slice(0, 4).map((id) => {
            const rec = recordsById.get(id);
            if (!rec) return null;
            return (
              <button
                key={id}
                type="button"
                onClick={() => onSelectRecord(rec)}
                className="rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 font-mono text-[10px] font-medium text-slate-700 hover:border-blue-600 hover:text-blue-700"
              >
                {id}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={onOpenFullBrief}
          className="whitespace-nowrap text-xs font-semibold text-blue-700 hover:underline"
        >
          {isFr ? 'Synthèse SI complète →' : 'Full SI Brief →'}
        </button>
      </div>
    </section>
  );
}
