import { Download } from 'lucide-react';
import type { CopyDictionary } from '../i18n/translations';
import type { Language } from '../types/fireSafety';

interface TelemetryRibbonProps {
  copy: CopyDictionary;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onExportBrief: () => void;
  recordCount: number;
}

export function TelemetryRibbon({
  copy,
  language,
  onLanguageChange,
  onExportBrief,
  recordCount,
}: TelemetryRibbonProps) {
  return (
    <div className="border-b border-slate-200 bg-slate-100/80">
      <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-4 px-6 py-2.5 text-xs text-slate-600">
        <div className="flex flex-wrap items-center gap-2 font-mono tabular-nums">
          <span className="font-medium text-slate-900">
            {recordCount > 0
              ? language === 'fr'
                ? `${recordCount} Fiches NASA PSI & ISS`
                : `${recordCount} NASA PSI & ISS Records`
              : copy.ribbonDataset}
          </span>
          <span aria-hidden="true">·</span>
          <span>{copy.ribbonMissions}</span>
          <span aria-hidden="true">·</span>
          <span>{copy.ribbonStandard}</span>
        </div>

        <div className="flex items-center gap-4">
          <div
            role="group"
            aria-label="Interface language"
            className="flex items-center gap-1 rounded-md border border-slate-200 bg-white p-0.5"
          >
            <button
              type="button"
              onClick={() => onLanguageChange('en')}
              className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1 text-xs font-medium transition-colors ${
                language === 'en'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => onLanguageChange('fr')}
              className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1 text-xs font-medium transition-colors ${
                language === 'fr'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              FR
            </button>
          </div>

          <button
            type="button"
            onClick={onExportBrief}
            className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 transition-colors"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{copy.exportBrief}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
