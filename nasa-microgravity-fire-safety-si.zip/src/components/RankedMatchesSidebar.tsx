import { translateMaterialLabel } from '../lib/fireSafetyEngine';
import type { Language, MicrogravityRecord, RankedEvidence } from '../types/fireSafety';

interface RankedMatchesSidebarProps {
  rankedEvidence: RankedEvidence[];
  language: Language;
  onSelectRecord: (record: MicrogravityRecord) => void;
  onOpenDeepVision: () => void;
}

function MiniSimilarityRing({ score }: { score: number }) {
  const size = 40;
  const stroke = 3.5;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - Math.max(0, Math.min(1, score / 100)));
  const color = score >= 70 ? '#2563EB' : score >= 45 ? '#D97706' : '#64748B';

  return (
    <div className="relative h-10 w-10 shrink-0">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={20} cy={20} r={r} fill="none" stroke="#E2E8F0" strokeWidth={stroke} />
        <circle
          cx={20}
          cy={20}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-semibold tabular-nums text-slate-900">
        {score}%
      </span>
    </div>
  );
}

export function RankedMatchesSidebar({
  rankedEvidence,
  language,
  onSelectRecord,
  onOpenDeepVision,
}: RankedMatchesSidebarProps) {
  const isFr = language === 'fr';
  const topExperiments = rankedEvidence
    .filter((e) => e.record.rowType === 'Essai solide' || e.record.rowType === 'Essai goutte')
    .slice(0, 5);

  return (
    <section
      aria-label={isFr ? 'Essais NASA les plus proches' : 'Closest NASA Trials'}
      className="flex h-full flex-col justify-between rounded-lg border border-slate-200 bg-white p-4 space-y-3"
    >
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-600">
            {isFr ? 'Top Essais NASA Analogues' : 'Top Analog NASA Trials'}
          </h2>
          <span className="font-mono text-[11px] text-slate-400">20 flights</span>
        </div>

        <div className="space-y-2">
          {topExperiments.map(({ record, similarityScore, mismatchFlags }) => {
            const metric =
              record.vfMmS !== null
                ? `Vf ${record.vfMmS} mm/s`
                : record.kHotMm2S !== null
                  ? `K ${record.kHotMm2S} mm²/s`
                  : record.initialObservation;
            return (
              <button
                key={record.id}
                type="button"
                onClick={() => onSelectRecord(record)}
                className="flex w-full items-center gap-3 rounded-md border border-slate-200 bg-slate-50/60 p-2.5 text-left hover:border-blue-600 hover:bg-white transition-colors"
              >
                <MiniSimilarityRing score={similarityScore} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-semibold text-slate-900">
                      {record.id} · {record.mission}
                    </span>
                    <span className="font-mono text-[11px] font-semibold tabular-nums text-blue-700">
                      {metric}
                    </span>
                  </div>
                  <div className="mt-0.5 truncate text-xs text-slate-700">
                    {translateMaterialLabel(record.materialOriginal, language)} · {record.o2Percent}% O₂ · {record.velocityCmS ?? 0} cm/s
                  </div>
                  {mismatchFlags[0] && (
                    <div className="mt-0.5 truncate text-[10px] text-amber-700">
                      ▲ {mismatchFlags[0]}
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <button
        type="button"
        onClick={onOpenDeepVision}
        className="w-full rounded-md border border-slate-300 bg-slate-900 px-3 py-2 text-xs font-medium text-white hover:bg-slate-800 transition-colors"
      >
        {isFr ? 'Vision Profonde : Explorer les 39 Fiches →' : 'Deep Vision: Filter All 39 Records →'}
      </button>
    </section>
  );
}
