import type { RefObject } from 'react';
import { Send } from 'lucide-react';
import type { CopyDictionary } from '../i18n/translations';
import { MISSION_PRESETS } from '../data/presets';
import { MATERIAL_CATALOG, UNKNOWN_MATERIAL_KEY } from '../lib/fireSafetyEngine';
import type {
  FlowDirection,
  GravityEnvironment,
  HabitatQuery,
  Language,
} from '../types/fireSafety';

interface HabitatQueryConsoleProps {
  copy: CopyDictionary;
  language: Language;
  query: HabitatQuery;
  isAnalyzing: boolean;
  activePresetId: string | null;
  questionInputRef: RefObject<HTMLTextAreaElement | null>;
  onUpdateQuery: (patch: Partial<HabitatQuery>) => void;
  onSelectPreset: (presetId: string) => void;
  onAskQuestion: () => void;
}

export function HabitatQueryConsole({
  copy,
  language,
  query,
  isAnalyzing,
  activePresetId,
  questionInputRef,
  onUpdateQuery,
  onSelectPreset,
  onAskQuestion,
}: HabitatQueryConsoleProps) {
  const flowDirections: FlowDirection[] = ['Concurrent', 'Opposé', 'Stagnant'];
  const gravities: GravityEnvironment[] = ['0g', 'lunar', 'mars'];

  return (
    <aside
      aria-label={copy.parametersHeading}
      className="w-full lg:w-[376px] shrink-0 space-y-6"
    >
      {/* Question & SI Query Card */}
      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <div className="mb-3 flex items-center justify-between gap-2">
          <h2 className="text-sm font-semibold text-slate-900">
            {copy.questionHeading}
          </h2>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            onAskQuestion();
          }}
          className="space-y-3"
        >
          <div>
            <label htmlFor="habitat-question-input" className="sr-only">
              {copy.questionHeading}
            </label>
            <textarea
              id="habitat-question-input"
              ref={questionInputRef}
              rows={3}
              value={query.questionText}
              onChange={(e) => onUpdateQuery({ questionText: e.target.value })}
              placeholder={copy.questionPlaceholder}
              className="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={isAnalyzing}
            className="flex w-full items-center justify-center gap-2 rounded-md bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 transition-colors"
          >
            <Send className="h-4 w-4" aria-hidden="true" />
            <span>{isAnalyzing ? copy.analyzingBtn : copy.analyzeBtn}</span>
          </button>
        </form>

        <div className="mt-5 border-t border-slate-200 pt-4">
          <p className="mb-2.5 text-xs font-medium text-slate-500">
            {copy.presetsLabel}
          </p>
          <div className="space-y-1.5">
            {MISSION_PRESETS.map((preset) => {
              const isActive = activePresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onSelectPreset(preset.id)}
                  className={`w-full rounded-md border px-3 py-2 text-left transition-colors ${
                    isActive
                      ? 'border-blue-600 bg-blue-50/70 text-slate-900'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-xs font-semibold text-slate-900">
                    {language === 'fr' ? preset.labelFr : preset.labelEn}
                  </div>
                  <div className="mt-0.5 font-mono text-[11px] tabular-nums text-slate-500">
                    {language === 'fr' ? preset.subtitleFr : preset.subtitleEn}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Parametric Habitat Controls */}
      <section className="rounded-lg border border-slate-200 bg-white p-5 space-y-5">
        <h2 className="text-sm font-semibold text-slate-900">
          {copy.parametersHeading}
        </h2>

        {/* Material Selector */}
        <div className="space-y-1.5">
          <label
            htmlFor="material-select"
            className="block text-xs font-medium text-slate-700"
          >
            {copy.materialLabel}
          </label>
          <select
            id="material-select"
            value={query.materialKey}
            onChange={(e) => onUpdateQuery({ materialKey: e.target.value })}
            className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            <option value={UNKNOWN_MATERIAL_KEY}>
              {copy.unknownMaterialOption}
            </option>
            {MATERIAL_CATALOG.map((mat) => (
              <option key={mat.loiKey} value={mat.loiKey}>
                {language === 'fr' ? mat.labelFr : mat.labelEn}
              </option>
            ))}
          </select>
        </div>

        {query.materialKey === UNKNOWN_MATERIAL_KEY && (
          <div className="space-y-1.5">
            <label
              htmlFor="custom-material-input"
              className="block text-xs font-medium text-slate-700"
            >
              {copy.customMaterialLabel}
            </label>
            <input
              id="custom-material-input"
              type="text"
              value={query.customMaterialName}
              onChange={(e) =>
                onUpdateQuery({ customMaterialName: e.target.value })
              }
              placeholder="e.g. Tissu X / Kapton / Vectran"
              className="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
            />
          </div>
        )}

        {/* O2 % */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label
              htmlFor="o2-range"
              className="text-xs font-medium text-slate-700"
            >
              {copy.o2Label}
            </label>
            <div className="flex items-center gap-1 font-mono text-sm font-semibold tabular-nums text-slate-900">
              <span>{query.o2Percent.toFixed(1)}</span>
              <span className="text-xs font-normal text-slate-500">%</span>
            </div>
          </div>
          <input
            id="o2-range"
            type="range"
            min={10}
            max={40}
            step={0.1}
            value={query.o2Percent}
            onChange={(e) =>
              onUpdateQuery({ o2Percent: Number(e.target.value) })
            }
            className="w-full accent-blue-600"
          />
          <div className="flex justify-between font-mono text-[11px] tabular-nums text-slate-400">
            <span>10%</span>
            <span>21% Air</span>
            <span>34% SEA</span>
            <span>40%</span>
          </div>
        </div>

        {/* Pressure atm */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label
              htmlFor="pressure-range"
              className="text-xs font-medium text-slate-700"
            >
              {copy.pressureLabel}
            </label>
            <div className="flex items-center gap-1 font-mono text-sm font-semibold tabular-nums text-slate-900">
              <span>{query.pressureAtm.toFixed(2)}</span>
              <span className="text-xs font-normal text-slate-500">atm</span>
            </div>
          </div>
          <input
            id="pressure-range"
            type="range"
            min={0.3}
            max={1.5}
            step={0.05}
            value={query.pressureAtm}
            onChange={(e) =>
              onUpdateQuery({ pressureAtm: Number(e.target.value) })
            }
            className="w-full accent-blue-600"
          />
          <div className="flex justify-between font-mono text-[11px] tabular-nums text-slate-400">
            <span>0.30</span>
            <span>0.60 SEA</span>
            <span>1.00 ISS</span>
            <span>1.50</span>
          </div>
        </div>

        {/* Airflow U */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label
              htmlFor="velocity-range"
              className="text-xs font-medium text-slate-700"
            >
              {copy.velocityLabel}
            </label>
            <div className="flex items-center gap-1 font-mono text-sm font-semibold tabular-nums text-slate-900">
              <span>{query.velocityCmS.toFixed(1)}</span>
              <span className="text-xs font-normal text-slate-500">cm/s</span>
            </div>
          </div>
          <input
            id="velocity-range"
            type="range"
            min={0}
            max={55}
            step={0.5}
            value={query.velocityCmS}
            onChange={(e) =>
              onUpdateQuery({ velocityCmS: Number(e.target.value) })
            }
            className="w-full accent-blue-600"
          />
          <div className="flex justify-between font-mono text-[11px] tabular-nums text-slate-400">
            <span>0</span>
            <span>15</span>
            <span>30</span>
            <span>47 Blowoff</span>
          </div>
        </div>

        {/* Flow Direction */}
        <div className="space-y-1.5">
          <span className="block text-xs font-medium text-slate-700">
            {copy.flowDirectionLabel}
          </span>
          <div className="grid grid-cols-3 gap-1 rounded-md border border-slate-200 bg-slate-100 p-1">
            {flowDirections.map((dir) => (
              <button
                key={dir}
                type="button"
                onClick={() => onUpdateQuery({ flowDirection: dir })}
                className={`whitespace-nowrap rounded px-2 py-1.5 text-xs font-medium transition-colors ${
                  query.flowDirection === dir
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {dir}
              </button>
            ))}
          </div>
        </div>

        {/* Gravity Regime */}
        <div className="space-y-1.5">
          <span className="block text-xs font-medium text-slate-700">
            {copy.gravityLabel}
          </span>
          <div className="grid grid-cols-3 gap-1 rounded-md border border-slate-200 bg-slate-100 p-1">
            {gravities.map((grav) => (
              <button
                key={grav}
                type="button"
                onClick={() => onUpdateQuery({ gravity: grav })}
                className={`truncate rounded px-2 py-1.5 text-xs font-medium transition-colors ${
                  query.gravity === grav
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {copy.gravityOptions[grav]}
              </button>
            ))}
          </div>
        </div>
      </section>
    </aside>
  );
}
